import type { Metadata } from "next";
import Link from "next/link";
import { Reveal } from "@/components/ui/reveal";
import { getCollections, getProducts } from "@/lib/queries";
import { formatPrice } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Collections",
  description: "Six curated shelves of games, assembled by the Bha Khan counter team.",
};

export default async function CollectionsPage() {
  const [collections, products] = await Promise.all([getCollections(), getProducts()]);

  return (
    <div className="mx-auto max-w-[1400px] px-5 py-14 sm:px-8">
      <header className="border-b border-edge pb-10">
        <Reveal>
          <p className="eyebrow text-gold">Curated shelves</p>
          <h1 className="mt-3 font-display text-[clamp(2.75rem,6vw,5rem)] leading-[0.95]">
            Collections
          </h1>
          <p className="mt-4 max-w-2xl text-sm leading-relaxed text-mist sm:text-base">
            Six shelves, assembled the way we&apos;d arrange them in a physical shop — by mood as
            much as by genre. Start where your head is at.
          </p>
        </Reveal>
      </header>

      <div className="mt-12 space-y-6">
        {collections.map((collection, index) => {
          const inCollection = products.filter((p) => p.collectionSlug === collection.slug);
          const cheapest = inCollection.reduce(
            (min, p) => Math.min(min, p.price),
            Number.POSITIVE_INFINITY,
          );

          return (
            <Reveal key={collection.slug} delay={index * 60}>
              <Link
                href={`/collections/${collection.slug}`}
                className="group grid overflow-hidden rounded-3xl border border-edge bg-panel/30 transition hover:border-gold/40 md:grid-cols-[320px_1fr]"
              >
                <div className="relative h-56 overflow-hidden md:h-full">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={collection.image}
                    alt={collection.name}
                    loading="lazy"
                    className="size-full object-cover transition-transform duration-[1100ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-110"
                  />
                  <div
                    className="absolute inset-0 opacity-60 mix-blend-multiply"
                    style={{
                      backgroundImage: `linear-gradient(150deg, ${collection.accentFrom}, ${collection.accentTo})`,
                    }}
                  />
                </div>

                <div className="flex flex-col justify-center gap-4 p-7 sm:p-10">
                  <div>
                    <p className="eyebrow text-gold">{collection.tagline}</p>
                    <h2 className="mt-3 font-display text-4xl leading-tight sm:text-5xl">
                      {collection.name}
                    </h2>
                  </div>
                  <p className="max-w-2xl text-sm leading-relaxed text-mist">
                    {collection.description}
                  </p>
                  <div className="flex flex-wrap items-center gap-5 text-xs text-mist">
                    <span>
                      <span className="text-bone tabular-nums">{inCollection.length}</span> titles
                    </span>
                    {Number.isFinite(cheapest) && (
                      <span>
                        From <span className="text-bone">{formatPrice(cheapest)}</span>
                      </span>
                    )}
                    <span className="inline-flex items-center gap-1.5 text-gold-soft">
                      Browse shelf
                      <svg
                        width="13"
                        height="13"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2.4"
                        className="transition-transform group-hover:translate-x-1"
                      >
                        <path d="M5 12h14M13 6l6 6-6 6" />
                      </svg>
                    </span>
                  </div>

                  <div className="mt-2 flex -space-x-3">
                    {inCollection.slice(0, 5).map((product) => (
                      /* eslint-disable-next-line @next/next/no-img-element */
                      <img
                        key={product.slug}
                        src={product.coverImage}
                        alt=""
                        loading="lazy"
                        className="size-12 rounded-lg border-2 border-ink object-cover"
                      />
                    ))}
                  </div>
                </div>
              </Link>
            </Reveal>
          );
        })}
      </div>
    </div>
  );
}
