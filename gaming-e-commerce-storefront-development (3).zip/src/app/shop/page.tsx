import type { Metadata } from "next";
import Link from "next/link";
import { FilterPanel, SortSelect } from "@/components/shop/filter-panel";
import { ProductCard } from "@/components/product/product-card";
import { Reveal } from "@/components/ui/reveal";
import { getCollections, getFacets, getProducts, type SortKey } from "@/lib/queries";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Shop all games",
  description:
    "Browse every title on the Bha Khan shelves — filter by platform, genre, collection and price.",
};

type SearchParams = Record<string, string | string[] | undefined>;

function first(value: string | string[] | undefined) {
  return Array.isArray(value) ? value[0] : value;
}

export default async function ShopPage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>;
}) {
  const sp = await searchParams;

  const q = first(sp.q)?.trim() || undefined;
  const platforms = first(sp.platform)?.split(",").filter(Boolean);
  const genres = first(sp.genre)?.split(",").filter(Boolean);
  const collection = first(sp.collection) || undefined;
  const maxRaw = Number(first(sp.max));
  const maxPrice = Number.isFinite(maxRaw) && maxRaw > 0 ? maxRaw : undefined;
  const onSale = first(sp.onSale) === "1";
  const sort = (first(sp.sort) as SortKey | undefined) ?? "featured";

  const [products, facets, collections] = await Promise.all([
    getProducts({ q, platforms, genres, collection, maxPrice, onSale, sort }),
    getFacets(),
    getCollections(),
  ]);

  const activeChips: { label: string; href: string }[] = [];
  const build = (mutate: (p: URLSearchParams) => void) => {
    const next = new URLSearchParams();
    for (const [key, value] of Object.entries(sp)) {
      const v = first(value);
      if (v) next.set(key, v);
    }
    mutate(next);
    const query = next.toString();
    return query ? `/shop?${query}` : "/shop";
  };

  if (q) activeChips.push({ label: `“${q}”`, href: build((p) => p.delete("q")) });
  for (const platform of platforms ?? []) {
    activeChips.push({
      label: platform,
      href: build((p) => {
        const rest = (platforms ?? []).filter((v) => v !== platform);
        if (rest.length) p.set("platform", rest.join(","));
        else p.delete("platform");
      }),
    });
  }
  for (const genre of genres ?? []) {
    activeChips.push({
      label: genre,
      href: build((p) => {
        const rest = (genres ?? []).filter((v) => v !== genre);
        if (rest.length) p.set("genre", rest.join(","));
        else p.delete("genre");
      }),
    });
  }
  if (collection) {
    const name = collections.find((c) => c.slug === collection)?.name ?? collection;
    activeChips.push({ label: name, href: build((p) => p.delete("collection")) });
  }
  if (onSale) activeChips.push({ label: "On sale", href: build((p) => p.delete("onSale")) });

  return (
    <div className="mx-auto max-w-[1400px] px-5 pt-14 sm:px-8">
      <header className="border-b border-edge pb-10">
        <Reveal>
          <p className="eyebrow text-gold">The shelves</p>
          <h1 className="mt-3 font-display text-[clamp(2.75rem,6vw,5rem)] leading-[0.95]">
            Every game we stock
          </h1>
          <p className="mt-4 max-w-2xl text-sm leading-relaxed text-mist sm:text-base">
            {facets.total} titles, each one played and written up by the shop. Filter by platform,
            genre or budget — or sort by what other customers are actually finishing.
          </p>
        </Reveal>
      </header>

      <div className="grid gap-10 py-10 lg:grid-cols-[260px_1fr] lg:gap-14">
        <aside>
          <FilterPanel facets={facets} collections={collections} resultCount={products.length} />
        </aside>

        <section>
          <div className="mb-6 hidden items-center justify-between gap-4 lg:flex">
            <p className="text-sm text-mist">
              Showing <span className="text-bone tabular-nums">{products.length}</span> of{" "}
              <span className="tabular-nums">{facets.total}</span> titles
            </p>
            <SortSelect />
          </div>

          {activeChips.length > 0 && (
            <div className="mb-6 flex flex-wrap items-center gap-2">
              {activeChips.map((chip) => (
                <Link
                  key={chip.label}
                  href={chip.href}
                  scroll={false}
                  className="group inline-flex items-center gap-2 rounded-full border border-gold/30 bg-gold/10 px-3 py-1.5 text-xs text-gold-soft transition hover:bg-gold/20"
                >
                  {chip.label}
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6">
                    <path d="M18 6 6 18M6 6l12 12" />
                  </svg>
                </Link>
              ))}
              <Link href="/shop" scroll={false} className="px-2 text-xs text-mist hover:text-bone">
                Clear all
              </Link>
            </div>
          )}

          {products.length === 0 ? (
            <div className="rounded-3xl border border-dashed border-edge px-8 py-24 text-center">
              <p className="font-display text-3xl">Nothing on this shelf</p>
              <p className="mx-auto mt-3 max-w-sm text-sm text-mist">
                Try widening your price range or clearing a filter — we restock weekly and take
                requests at the counter.
              </p>
              <Link
                href="/shop"
                className="mt-7 inline-block rounded-full bg-bone px-7 py-3 text-sm font-bold text-void transition hover:bg-gold-soft"
              >
                Reset filters
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-5 xl:grid-cols-3">
              {products.map((product, index) => (
                <Reveal key={product.slug} delay={(index % 3) * 60}>
                  <ProductCard product={product} priority={index < 6} />
                </Reveal>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
