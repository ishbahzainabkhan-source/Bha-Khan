import { NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { isAdmin } from "@/lib/admin";

export const dynamic = "force-dynamic";

const STATUSES = ["confirmed", "packing", "shipped", "delivered", "refunded"];

export async function GET() {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  }
  const rows = await db.select().from(orders);
  return NextResponse.json({ orders: rows });
}

export async function PATCH(request: Request) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  }
  const body = (await request.json().catch(() => ({}))) as { id?: number; status?: string };
  const id = Number(body.id);
  const status = String(body.status ?? "");

  if (!id || !STATUSES.includes(status)) {
    return NextResponse.json({ error: "Invalid order update." }, { status: 400 });
  }

  const [updated] = await db
    .update(orders)
    .set({ status })
    .where(eq(orders.id, id))
    .returning();

  if (!updated) return NextResponse.json({ error: "Order not found." }, { status: 404 });
  return NextResponse.json({ order: updated });
}
