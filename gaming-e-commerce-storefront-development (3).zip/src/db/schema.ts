import {
  boolean,
  integer,
  jsonb,
  pgTable,
  real,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const collections = pgTable("collections", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  tagline: text("tagline").notNull(),
  description: text("description").notNull(),
  image: text("image").notNull(),
  accentFrom: text("accent_from").notNull(),
  accentTo: text("accent_to").notNull(),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  tagline: text("tagline").notNull(),
  description: text("description").notNull(),
  story: text("story").notNull(),
  price: integer("price").notNull(),
  compareAtPrice: integer("compare_at_price"),
  platform: text("platform").notNull(),
  genre: text("genre").notNull(),
  edition: text("edition").notNull(),
  publisher: text("publisher").notNull(),
  developer: text("developer").notNull(),
  releaseYear: integer("release_year").notNull(),
  rated: text("rated").notNull(),
  players: text("players").notNull(),
  playtime: text("playtime").notNull(),
  stock: integer("stock").notNull().default(0),
  featured: boolean("featured").notNull().default(false),
  isNew: boolean("is_new").notNull().default(false),
  collectionSlug: text("collection_slug").notNull(),
  coverImage: text("cover_image").notNull(),
  gallery: jsonb("gallery").$type<string[]>().notNull(),
  highlights: jsonb("highlights").$type<string[]>().notNull(),
  tags: jsonb("tags").$type<string[]>().notNull(),
  ratingAvg: real("rating_avg").notNull().default(0),
  ratingCount: integer("rating_count").notNull().default(0),
  soldCount: integer("sold_count").notNull().default(0),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  productSlug: text("product_slug").notNull(),
  author: text("author").notNull(),
  location: text("location").notNull().default(""),
  rating: integer("rating").notNull(),
  title: text("title").notNull(),
  body: text("body").notNull(),
  verified: boolean("verified").notNull().default(true),
  helpful: integer("helpful").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type OrderLine = {
  slug: string;
  title: string;
  edition: string;
  platform: string;
  price: number;
  quantity: number;
  coverImage: string;
};

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderNumber: text("order_number").notNull().unique(),
  email: text("email").notNull(),
  fullName: text("full_name").notNull(),
  address: text("address").notNull().default(""),
  city: text("city").notNull().default(""),
  postalCode: text("postal_code").notNull().default(""),
  country: text("country").notNull().default(""),
  deliveryMethod: text("delivery_method").notNull().default("digital"),
  promoCode: text("promo_code"),
  subtotal: integer("subtotal").notNull(),
  discount: integer("discount").notNull().default(0),
  shipping: integer("shipping").notNull().default(0),
  tax: integer("tax").notNull().default(0),
  total: integer("total").notNull(),
  items: jsonb("items").$type<OrderLine[]>().notNull(),
  status: text("status").notNull().default("confirmed"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Product = typeof products.$inferSelect;
export type Collection = typeof collections.$inferSelect;
export type Review = typeof reviews.$inferSelect;
export type Order = typeof orders.$inferSelect;
