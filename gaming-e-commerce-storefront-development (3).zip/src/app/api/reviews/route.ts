import { db } from "@/db";
import { reviews } from "@/db/schema";
import { getProduct, refreshProductRating } from "@/lib/queries";
import { revalidatePath } from "next/cache";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const payload = (await request.json()) as {
      productSlug?: string;
      author?: string;
      location?: string;
      rating?: number;
      title?: string;
      body?: string;
    };

    const productSlug = (payload.productSlug ?? "").split("--")[0];
    const author = (payload.author ?? "").trim().slice(0, 80);
    const title = (payload.title ?? "").trim().slice(0, 120);
    const body = (payload.body ?? "").trim().slice(0, 2000);
    const location = (payload.location ?? "").trim().slice(0, 80);
    const rating = Math.max(1, Math.min(5, Math.round(Number(payload.rating) || 5)));

    if (!productSlug || !author || !title || body.length < 10) {
      return Response.json({ error: "Invalid review payload" }, { status: 400 });
    }

    const product = await getProduct(productSlug);
    if (!product) return Response.json({ error: "Product not found" }, { status: 404 });

    const inserted = await db
      .insert(reviews)
      .values({
        productSlug,
        author,
        location,
        rating,
        title,
        body,
        verified: false,
        helpful: 0,
      })
      .returning();

    await refreshProductRating(productSlug);
    revalidatePath(`/product/${productSlug}`);

    const review = inserted[0];
    return Response.json({
      review: {
        id: review.id,
        author: review.author,
        location: review.location,
        rating: review.rating,
        title: review.title,
        body: review.body,
        verified: review.verified,
        helpful: review.helpful,
        createdAt: review.createdAt.toISOString(),
      },
    });
  } catch {
    return Response.json({ error: "Unable to save review" }, { status: 500 });
  }
}
