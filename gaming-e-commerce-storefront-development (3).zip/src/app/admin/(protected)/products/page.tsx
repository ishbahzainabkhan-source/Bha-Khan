import { getAdminProducts } from "@/lib/admin";
import { getCollections } from "@/lib/queries";
import { ProductsManager } from "./products-manager";

export const dynamic = "force-dynamic";

export default async function AdminProductsPage() {
  const [products, collections] = await Promise.all([getAdminProducts(), getCollections()]);
  return <ProductsManager initialProducts={products} collections={collections} />;
}
