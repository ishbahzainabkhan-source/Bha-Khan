import { cx } from "@/lib/format";

const StarPath = () => (
  <path d="M12 2.6l2.74 5.86 6.26.84-4.6 4.5 1.14 6.3L12 17.1l-5.54 3 1.14-6.3-4.6-4.5 6.26-.84L12 2.6z" />
);

export function Stars({
  value,
  size = 14,
  className,
}: {
  value: number;
  size?: number;
  className?: string;
}) {
  const clamped = Math.max(0, Math.min(5, value));
  const percent = (clamped / 5) * 100;

  return (
    <span
      className={cx("relative inline-flex shrink-0 align-middle", className)}
      aria-label={`${clamped.toFixed(1)} out of 5 stars`}
      role="img"
    >
      <span className="flex gap-[2px] text-edge">
        {Array.from({ length: 5 }).map((_, index) => (
          <svg key={index} width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
            <StarPath />
          </svg>
        ))}
      </span>
      <span
        className="pointer-events-none absolute inset-0 overflow-hidden text-gold"
        style={{ width: `${percent}%` }}
      >
        <span className="flex gap-[2px]">
          {Array.from({ length: 5 }).map((_, index) => (
            <svg
              key={index}
              width={size}
              height={size}
              viewBox="0 0 24 24"
              fill="currentColor"
              className="shrink-0"
            >
              <StarPath />
            </svg>
          ))}
        </span>
      </span>
    </span>
  );
}
