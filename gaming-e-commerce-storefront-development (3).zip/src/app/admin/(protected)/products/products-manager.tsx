"use client";

import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import type { Collection, Product } from "@/db/schema";
import { cx, formatPrice } from "@/lib/format";

type Draft = {
  id?: number;
  title: string;
  slug: string;
  tagline: string;
  description: string;
  price: number;
  compareAtPrice: number | null;
  platform: string;
  genre: string;
  edition: string;
  developer: string;
  publisher: string;
  releaseYear: number;
  stock: number;
  featured: boolean;
  isNew: boolean;
  collectionSlug: string;
  coverImage: string;
  highlights: string;
  tags: string;
};

const PLATFORMS = ["PC", "PlayStation 5", "Xbox Series X", "Nintendo Switch"];
const GENRES = [
  "Shooter",
  "RPG",
  "Racing",
  "Simulation",
  "Strategy",
  "Stealth",
  "Adventure",
  "Horror",
  "Arcade",
  "Roguelike",
];

const emptyDraft = (collectionSlug: string): Draft => ({
  title: "",
  slug: "",
  tagline: "",
  description: "",
  price: 2999,
  compareAtPrice: null,
  platform: "PC",
  genre: "Adventure",
  edition: "Standard Edition",
  developer: "",
  publisher: "",
  releaseYear: new Date().getFullYear(),
  stock: 20,
  featured: false,
  isNew: true,
  collectionSlug,
  coverImage: "",
  highlights: "",
  tags: "",
});

const toDraft = (product: Product): Draft => ({
  id: product.id,
  title: product.title,
  slug: product.slug,
  tagline: product.tagline,
  description: product.description,
  price: product.price,
  compareAtPrice: product.compareAtPrice,
  platform: product.platform,
  genre: product.genre,
  edition: product.edition,
  developer: product.developer,
  publisher: product.publisher,
  releaseYear: product.releaseYear,
  stock: product.stock,
  featured: product.featured,
  isNew: product.isNew,
  collectionSlug: product.collectionSlug,
  coverImage: product.coverImage,
  highlights: product.highlights.join(", "),
  tags: product.tags.join(", "),
});

const input =
  "w-full rounded-xl border border-edge bg-void/60 px-3.5 py-2.5 text-sm outline-none transition focus:border-gold/50 placeholder:text-mist/50";
const label = "text-[10px] tracking-[0.18em] text-mist uppercase";

export function ProductsManager({
  initialProducts,
  collections,
}: {
  initialProducts: Product[];
  collections: Collection[];
}) {
  const router = useRouter();
  const [rows, setRows] = useState(initialProducts);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [query, setQuery] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [flash, setFlash] = useState("");

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    if (!term) return rows;
    return rows.filter((row) =>
      [row.title, row.genre, row.platform, row.slug].join(" ").toLowerCase().includes(term),
    );
  }, [rows, query]);

  const set = <K extends keyof Draft>(key: K, value: Draft[K]) =>
    setDraft((current) => (current ? { ...current, [key]: value } : current));

  const save = async () => {
    if (!draft) return;
    setBusy(true);
    setError("");
    const payload = {
      ...draft,
      highlights: draft.highlights
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean),
      tags: draft.tags
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean),
    };
    try {
      const response = await fetch("/api/admin/products", {
        method: draft.id ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = (await response.json()) as { product?: Product; error?: string };
      if (!response.ok || !data.product) throw new Error(data.error ?? "Save failed.");
      setRows((current) =>
        draft.id
          ? current.map((row) => (row.id === data.product!.id ? data.product! : row))
          : [data.product!, ...current],
      );
      setFlash(draft.id ? "Product updated." : "Product added to the catalogue.");
      setDraft(null);
      router.refresh();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Save failed.");
    } finally {
      setBusy(false);
    }
  };

  const quickPatch = async (id: number, patch: Record<string, unknown>) => {
    const response = await fetch("/api/admin/products", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, ...patch }),
    });
    const data = (await response.json()) as { product?: Product; error?: string };
    if (data.product) {
      setRows((current) => current.map((row) => (row.id === id ? data.product! : row)));
      setFlash("Saved.");
      router.refresh();
    } else {
      setError(data.error ?? "Update failed.");
    }
  };

  const remove = async (product: Product) => {
    if (!window.confirm(`Remove “${product.title}” from the catalogue?`)) return;
    const response = await fetch(`/api/admin/products?id=${product.id}`, { method: "DELETE" });
    if (response.ok) {
      setRows((current) => current.filter((row) => row.id !== product.id));
      setFlash("Product removed.");
      router.refresh();
    } else {
      setError("Could not remove that product.");
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search catalogue…"
          className={`${input} max-w-xs`}
        />
        <span className="text-xs text-mist tabular-nums">
          {filtered.length} of {rows.length} titles
        </span>
        <button
          type="button"
          onClick={() => setDraft(emptyDraft(collections[0]?.slug ?? "arcade-vault"))}
          className="ml-auto rounded-full bg-gradient-to-r from-gold-soft via-gold to-gold-soft bg-[length:200%_100%] px-6 py-2.5 text-sm font-bold text-void transition-[background-position] duration-700 hover:bg-right"
        >
          + New product
        </button>
      </div>

      {flash && (
        <p className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-4 py-2.5 text-xs text-emerald-300">
          {flash}
        </p>
      )}
      {error && (
        <p className="rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-2.5 text-xs text-rose-300">
          {error}
        </p>
      )}

      <div className="overflow-x-auto rounded-2xl border border-edge bg-panel/30">
        <table className="w-full min-w-[900px] text-sm">
          <thead>
            <tr className="border-b border-edge text-left text-[10px] tracking-[0.16em] text-mist uppercase">
              <th className="px-5 py-3">Title</th>
              <th className="px-3 py-3">Platform</th>
              <th className="px-3 py-3">Genre</th>
              <th className="px-3 py-3">Price (¢)</th>
              <th className="px-3 py-3">Stock</th>
              <th className="px-3 py-3">Flags</th>
              <th className="px-5 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-edge">
            {filtered.map((product) => (
              <tr key={product.id} className="transition hover:bg-panel/60">
                <td className="px-5 py-3">
                  <div className="flex items-center gap-3">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={product.coverImage}
                      alt=""
                      className="size-10 shrink-0 rounded-lg object-cover"
                    />
                    <div className="min-w-0">
                      <p className="truncate font-medium">{product.title}</p>
                      <p className="truncate text-[11px] text-mist">{product.slug}</p>
                    </div>
                  </div>
                </td>
                <td className="px-3 py-3 text-xs text-mist">{product.platform}</td>
                <td className="px-3 py-3 text-xs text-mist">{product.genre}</td>
                <td className="px-3 py-3">
                  <input
                    type="number"
                    defaultValue={product.price}
                    onBlur={(event) => {
                      const value = Number(event.target.value);
                      if (value !== product.price && value >= 0) quickPatch(product.id, { price: value });
                    }}
                    className="w-24 rounded-lg border border-edge bg-void/60 px-2 py-1 text-xs tabular-nums outline-none focus:border-gold/50"
                  />
                </td>
                <td className="px-3 py-3">
                  <input
                    type="number"
                    defaultValue={product.stock}
                    onBlur={(event) => {
                      const value = Number(event.target.value);
                      if (value !== product.stock && value >= 0) quickPatch(product.id, { stock: value });
                    }}
                    className={cx(
                      "w-20 rounded-lg border bg-void/60 px-2 py-1 text-xs tabular-nums outline-none focus:border-gold/50",
                      product.stock <= 10 ? "border-rose-500/40 text-rose-300" : "border-edge",
                    )}
                  />
                </td>
                <td className="px-3 py-3">
                  <div className="flex gap-1.5">
                    <button
                      type="button"
                      onClick={() => quickPatch(product.id, { featured: !product.featured })}
                      className={cx(
                        "rounded-full border px-2 py-1 text-[10px] transition",
                        product.featured
                          ? "border-gold/50 bg-gold/15 text-gold-soft"
                          : "border-edge text-mist hover:text-bone",
                      )}
                    >
                      Featured
                    </button>
                    <button
                      type="button"
                      onClick={() => quickPatch(product.id, { isNew: !product.isNew })}
                      className={cx(
                        "rounded-full border px-2 py-1 text-[10px] transition",
                        product.isNew
                          ? "border-cyan-400/40 bg-cyan-400/10 text-cyan-300"
                          : "border-edge text-mist hover:text-bone",
                      )}
                    >
                      New
                    </button>
                  </div>
                </td>
                <td className="px-5 py-3">
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setDraft(toDraft(product))}
                      className="rounded-full border border-edge px-3 py-1 text-[11px] transition hover:border-gold/50 hover:text-gold-soft"
                    >
                      Edit
                    </button>
                    <a
                      href={`/product/${product.slug}`}
                      target="_blank"
                      rel="noreferrer"
                      className="rounded-full border border-edge px-3 py-1 text-[11px] text-mist transition hover:text-bone"
                    >
                      View
                    </a>
                    <button
                      type="button"
                      onClick={() => remove(product)}
                      className="rounded-full border border-rose-500/30 px-3 py-1 text-[11px] text-rose-300 transition hover:bg-rose-500/10"
                    >
                      Delete
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {draft && (
        <div className="fixed inset-0 z-[95] flex items-start justify-center overflow-y-auto bg-black/75 p-4 backdrop-blur-sm sm:p-8">
          <div className="w-full max-w-3xl rounded-3xl border border-edge bg-ink p-6 sm:p-8">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="eyebrow text-gold">{draft.id ? "Edit product" : "New product"}</p>
                <h2 className="mt-2 font-display text-3xl">
                  {draft.id ? draft.title : "Add a title"}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setDraft(null)}
                className="grid size-9 place-items-center rounded-full border border-edge text-mist hover:text-bone"
                aria-label="Close editor"
              >
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M18 6 6 18M6 6l12 12" />
                </svg>
              </button>
            </div>

            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              <label className="sm:col-span-2">
                <span className={label}>Title</span>
                <input className={`${input} mt-1.5`} value={draft.title} onChange={(e) => set("title", e.target.value)} />
              </label>
              <label>
                <span className={label}>Slug (optional)</span>
                <input className={`${input} mt-1.5`} value={draft.slug} onChange={(e) => set("slug", e.target.value)} placeholder="auto from title" />
              </label>
              <label>
                <span className={label}>Edition</span>
                <input className={`${input} mt-1.5`} value={draft.edition} onChange={(e) => set("edition", e.target.value)} />
              </label>
              <label className="sm:col-span-2">
                <span className={label}>Tagline</span>
                <input className={`${input} mt-1.5`} value={draft.tagline} onChange={(e) => set("tagline", e.target.value)} />
              </label>
              <label className="sm:col-span-2">
                <span className={label}>Short description</span>
                <textarea rows={2} className={`${input} mt-1.5 resize-none`} value={draft.description} onChange={(e) => set("description", e.target.value)} />
              </label>
              <label>
                <span className={label}>Price (cents)</span>
                <input type="number" className={`${input} mt-1.5 tabular-nums`} value={draft.price} onChange={(e) => set("price", Number(e.target.value))} />
                <span className="mt-1 block text-[11px] text-mist">{formatPrice(draft.price)}</span>
              </label>
              <label>
                <span className={label}>Compare-at price (cents)</span>
                <input type="number" className={`${input} mt-1.5 tabular-nums`} value={draft.compareAtPrice ?? ""} onChange={(e) => set("compareAtPrice", e.target.value ? Number(e.target.value) : null)} />
              </label>
              <label>
                <span className={label}>Platform</span>
                <select className={`${input} mt-1.5`} value={draft.platform} onChange={(e) => set("platform", e.target.value)}>
                  {PLATFORMS.map((item) => (
                    <option key={item} value={item} className="bg-ink">{item}</option>
                  ))}
                </select>
              </label>
              <label>
                <span className={label}>Genre</span>
                <select className={`${input} mt-1.5`} value={draft.genre} onChange={(e) => set("genre", e.target.value)}>
                  {GENRES.map((item) => (
                    <option key={item} value={item} className="bg-ink">{item}</option>
                  ))}
                </select>
              </label>
              <label>
                <span className={label}>Collection</span>
                <select className={`${input} mt-1.5`} value={draft.collectionSlug} onChange={(e) => set("collectionSlug", e.target.value)}>
                  {collections.map((item) => (
                    <option key={item.slug} value={item.slug} className="bg-ink">{item.name}</option>
                  ))}
                </select>
              </label>
              <label>
                <span className={label}>Stock</span>
                <input type="number" className={`${input} mt-1.5 tabular-nums`} value={draft.stock} onChange={(e) => set("stock", Number(e.target.value))} />
              </label>
              <label>
                <span className={label}>Developer</span>
                <input className={`${input} mt-1.5`} value={draft.developer} onChange={(e) => set("developer", e.target.value)} />
              </label>
              <label>
                <span className={label}>Publisher</span>
                <input className={`${input} mt-1.5`} value={draft.publisher} onChange={(e) => set("publisher", e.target.value)} />
              </label>
              <label>
                <span className={label}>Release year</span>
                <input type="number" className={`${input} mt-1.5 tabular-nums`} value={draft.releaseYear} onChange={(e) => set("releaseYear", Number(e.target.value))} />
              </label>
              <label className="sm:col-span-2">
                <span className={label}>Cover image URL</span>
                <input className={`${input} mt-1.5`} value={draft.coverImage} onChange={(e) => set("coverImage", e.target.value)} placeholder="/images/covers/… or https://…" />
              </label>
              <label className="sm:col-span-2">
                <span className={label}>Highlights (comma separated)</span>
                <textarea rows={2} className={`${input} mt-1.5 resize-none`} value={draft.highlights} onChange={(e) => set("highlights", e.target.value)} />
              </label>
              <label className="sm:col-span-2">
                <span className={label}>Tags (comma separated)</span>
                <input className={`${input} mt-1.5`} value={draft.tags} onChange={(e) => set("tags", e.target.value)} />
              </label>
              <div className="flex gap-6 sm:col-span-2">
                <label className="flex items-center gap-2 text-sm">
                  <input type="checkbox" checked={draft.featured} onChange={(e) => set("featured", e.target.checked)} className="size-4 accent-[#d9b26a]" />
                  Featured on home page
                </label>
                <label className="flex items-center gap-2 text-sm">
                  <input type="checkbox" checked={draft.isNew} onChange={(e) => set("isNew", e.target.checked)} className="size-4 accent-[#d9b26a]" />
                  Show “New” badge
                </label>
              </div>
            </div>

            {error && (
              <p className="mt-4 rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-2.5 text-xs text-rose-300">
                {error}
              </p>
            )}

            <div className="mt-7 flex items-center justify-between gap-4 border-t border-edge pt-5">
              <button type="button" onClick={() => setDraft(null)} className="text-sm text-mist hover:text-bone">
                Cancel
              </button>
              <button
                type="button"
                disabled={busy || draft.title.trim().length < 2}
                onClick={save}
                className="rounded-full bg-bone px-8 py-3 text-sm font-bold text-void transition hover:bg-gold-soft disabled:opacity-40"
              >
                {busy ? "Saving…" : draft.id ? "Save changes" : "Create product"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
