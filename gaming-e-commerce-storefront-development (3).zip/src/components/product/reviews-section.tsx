"use client";

import { useMemo, useState, type FormEvent } from "react";
import { Stars } from "@/components/ui/stars";
import { cx, formatDate } from "@/lib/format";

export type ReviewItem = {
  id: number;
  author: string;
  location: string;
  rating: number;
  title: string;
  body: string;
  verified: boolean;
  helpful: number;
  createdAt: string;
};

type SortMode = "helpful" | "recent" | "high" | "low";

export function ReviewsSection({
  productSlug,
  productTitle,
  initialReviews,
}: {
  productSlug: string;
  productTitle: string;
  initialReviews: ReviewItem[];
}) {
  const [reviews, setReviews] = useState(initialReviews);
  const [sort, setSort] = useState<SortMode>("helpful");
  const [formOpen, setFormOpen] = useState(false);
  const [rating, setRating] = useState(5);
  const [hover, setHover] = useState(0);
  const [author, setAuthor] = useState("");
  const [location, setLocation] = useState("");
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [status, setStatus] = useState<"idle" | "saving" | "error" | "done">("idle");
  const [voted, setVoted] = useState<Record<number, boolean>>({});

  const summary = useMemo(() => {
    const total = reviews.length;
    const sum = reviews.reduce((acc, review) => acc + review.rating, 0);
    const buckets = [5, 4, 3, 2, 1].map((star) => ({
      star,
      count: reviews.filter((review) => review.rating === star).length,
    }));
    return { total, average: total ? sum / total : 0, buckets };
  }, [reviews]);

  const sorted = useMemo(() => {
    const copy = [...reviews];
    switch (sort) {
      case "recent":
        return copy.sort(
          (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
        );
      case "high":
        return copy.sort((a, b) => b.rating - a.rating || b.helpful - a.helpful);
      case "low":
        return copy.sort((a, b) => a.rating - b.rating || b.helpful - a.helpful);
      default:
        return copy.sort((a, b) => b.helpful - a.helpful);
    }
  }, [reviews, sort]);

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (!author.trim() || !title.trim() || body.trim().length < 10) {
      setStatus("error");
      return;
    }
    setStatus("saving");
    try {
      const response = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productSlug,
          author: author.trim(),
          location: location.trim(),
          rating,
          title: title.trim(),
          body: body.trim(),
        }),
      });
      if (!response.ok) throw new Error("failed");
      const data = (await response.json()) as { review: ReviewItem };
      setReviews((current) => [data.review, ...current]);
      setStatus("done");
      setFormOpen(false);
      setAuthor("");
      setLocation("");
      setTitle("");
      setBody("");
      setRating(5);
    } catch {
      setStatus("error");
    }
  };

  return (
    <section id="reviews" className="scroll-mt-28 border-t border-edge pt-14">
      <div className="grid gap-10 lg:grid-cols-[320px_1fr] lg:gap-16">
        <div className="lg:sticky lg:top-28 lg:self-start">
          <p className="eyebrow text-gold">Verified reviews</p>
          <h2 className="mt-3 font-display text-4xl">What players say</h2>

          <div className="mt-6 flex items-end gap-4">
            <span className="font-display text-6xl leading-none">
              {summary.average.toFixed(1)}
            </span>
            <div className="pb-1.5">
              <Stars value={summary.average} size={16} />
              <p className="mt-1 text-xs text-mist">
                {summary.total} review{summary.total === 1 ? "" : "s"} for {productTitle}
              </p>
            </div>
          </div>

          <ul className="mt-6 space-y-2">
            {summary.buckets.map((bucket) => (
              <li key={bucket.star} className="flex items-center gap-3 text-xs text-mist">
                <span className="w-8 tabular-nums">{bucket.star}★</span>
                <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-edge">
                  <span
                    className="block h-full rounded-full bg-gold transition-[width] duration-700"
                    style={{
                      width: `${summary.total ? (bucket.count / summary.total) * 100 : 0}%`,
                    }}
                  />
                </span>
                <span className="w-6 text-right tabular-nums">{bucket.count}</span>
              </li>
            ))}
          </ul>

          <button
            type="button"
            onClick={() => setFormOpen((value) => !value)}
            className="mt-7 w-full rounded-full border border-gold/40 bg-gold/10 px-6 py-3 text-sm font-semibold text-gold-soft transition hover:bg-gold hover:text-void"
          >
            {formOpen ? "Close form" : "Write a review"}
          </button>
          {status === "done" && (
            <p className="mt-3 text-center text-xs text-emerald-400">
              Thanks — your review is live.
            </p>
          )}
        </div>

        <div>
          {formOpen && (
            <form
              onSubmit={submit}
              className="mb-8 rounded-2xl border border-edge bg-panel/40 p-6"
            >
              <p className="font-display text-2xl">Share your verdict</p>

              <div className="mt-5">
                <p className="eyebrow text-mist">Your rating</p>
                <div className="mt-2 flex gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onMouseEnter={() => setHover(star)}
                      onMouseLeave={() => setHover(0)}
                      onClick={() => setRating(star)}
                      aria-label={`${star} star${star === 1 ? "" : "s"}`}
                      className={cx(
                        "transition-transform hover:scale-110",
                        (hover || rating) >= star ? "text-gold" : "text-edge",
                      )}
                    >
                      <svg width="26" height="26" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 2.6l2.74 5.86 6.26.84-4.6 4.5 1.14 6.3L12 17.1l-5.54 3 1.14-6.3-4.6-4.5 6.26-.84L12 2.6z" />
                      </svg>
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-5 grid gap-4 sm:grid-cols-2">
                <input
                  value={author}
                  onChange={(event) => setAuthor(event.target.value)}
                  placeholder="Your name"
                  required
                  className="rounded-xl border border-edge bg-void/60 px-4 py-3 text-sm outline-none transition focus:border-gold/50 placeholder:text-mist/60"
                />
                <input
                  value={location}
                  onChange={(event) => setLocation(event.target.value)}
                  placeholder="City, country (optional)"
                  className="rounded-xl border border-edge bg-void/60 px-4 py-3 text-sm outline-none transition focus:border-gold/50 placeholder:text-mist/60"
                />
              </div>
              <input
                value={title}
                onChange={(event) => setTitle(event.target.value)}
                placeholder="Headline"
                required
                className="mt-4 w-full rounded-xl border border-edge bg-void/60 px-4 py-3 text-sm outline-none transition focus:border-gold/50 placeholder:text-mist/60"
              />
              <textarea
                value={body}
                onChange={(event) => setBody(event.target.value)}
                placeholder="What worked, what didn't, who should buy it…"
                rows={4}
                required
                className="mt-4 w-full resize-none rounded-xl border border-edge bg-void/60 px-4 py-3 text-sm outline-none transition focus:border-gold/50 placeholder:text-mist/60"
              />
              {status === "error" && (
                <p className="mt-3 text-xs text-rose-400">
                  Please add your name, a headline and at least 10 characters of review.
                </p>
              )}
              <button
                type="submit"
                disabled={status === "saving"}
                className="mt-5 rounded-full bg-bone px-7 py-3 text-sm font-bold text-void transition hover:bg-gold-soft disabled:opacity-50"
              >
                {status === "saving" ? "Publishing…" : "Publish review"}
              </button>
            </form>
          )}

          <div className="mb-6 flex flex-wrap items-center gap-2">
            {(
              [
                ["helpful", "Most helpful"],
                ["recent", "Most recent"],
                ["high", "Highest rated"],
                ["low", "Lowest rated"],
              ] as [SortMode, string][]
            ).map(([mode, label]) => (
              <button
                key={mode}
                type="button"
                onClick={() => setSort(mode)}
                className={cx(
                  "rounded-full border px-3.5 py-1.5 text-xs transition",
                  sort === mode
                    ? "border-gold/50 bg-gold/10 text-gold-soft"
                    : "border-edge text-mist hover:text-bone",
                )}
              >
                {label}
              </button>
            ))}
          </div>

          <ul className="space-y-5">
            {sorted.map((review) => (
              <li key={review.id} className="rounded-2xl border border-edge bg-panel/30 p-6">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <span className="grid size-10 place-items-center rounded-full bg-gradient-to-br from-gold/30 to-violet/20 text-xs font-bold">
                      {review.author
                        .split(" ")
                        .map((part) => part[0])
                        .join("")
                        .slice(0, 2)
                        .toUpperCase()}
                    </span>
                    <div>
                      <p className="text-sm font-semibold">{review.author}</p>
                      <p className="text-[11px] text-mist">
                        {review.location ? `${review.location} · ` : ""}
                        {formatDate(review.createdAt)}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {review.verified && (
                      <span className="rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-1 text-[10px] tracking-wide text-emerald-400 uppercase">
                        Verified buyer
                      </span>
                    )}
                    <Stars value={review.rating} size={13} />
                  </div>
                </div>

                <h3 className="mt-4 font-display text-xl">{review.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-mist">{review.body}</p>

                <button
                  type="button"
                  onClick={() => setVoted((current) => ({ ...current, [review.id]: true }))}
                  className={cx(
                    "mt-4 inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-[11px] transition",
                    voted[review.id]
                      ? "border-gold/40 text-gold-soft"
                      : "border-edge text-mist hover:text-bone",
                  )}
                >
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M7 11v9H4a1 1 0 0 1-1-1v-7a1 1 0 0 1 1-1h3Zm0 0 4.5-8a2.2 2.2 0 0 1 3 2.7L13.5 9H19a2 2 0 0 1 2 2.4l-1.3 6A2 2 0 0 1 17.7 19H7" />
                  </svg>
                  Helpful ({review.helpful + (voted[review.id] ? 1 : 0)})
                </button>
              </li>
            ))}
          </ul>

          {sorted.length === 0 && (
            <p className="rounded-2xl border border-dashed border-edge px-6 py-16 text-center text-sm text-mist">
              No reviews yet — be the first to write one.
            </p>
          )}
        </div>
      </div>
    </section>
  );
}
