import { cookies } from "next/headers";
import { db } from "@/db";
import { orders, products, reviews } from "@/db/schema";
import { desc, eq, lte, sql } from "drizzle-orm";

export const ADMIN_COOKIE = "bk_admin";

export function adminPasscode() {
  return process.env.ADMIN_PASSCODE ?? "khan2026";
}

export function tokenFor(passcode: string) {
  return Buffer.from(`bk::${passcode}`).toString("base64url");
}

export async function isAdmin() {
  const store = await cookies();
  return store.get(ADMIN_COOKIE)?.value === tokenFor(adminPasscode());
}

export async function getAdminStats() {
  await ensureData();

  const [orderAgg] = await db
    .select({
      count: sql<number>`count(*)::int`,
      revenue: sql<number>`coalesce(sum(${orders.total}), 0)::int`,
      discount: sql<number>`coalesce(sum(${orders.discount}), 0)::int`,
      units: sql<number>`coalesce(sum(jsonb_array_length(${orders.items})), 0)::int`,
    })
    .from(orders);

  const [productAgg] = await db
    .select({
      count: sql<number>`count(*)::int`,
      stock: sql<number>`coalesce(sum(${products.stock}), 0)::int`,
      featured: sql<number>`count(*) filter (where ${products.featured})::int`,
      sold: sql<number>`coalesce(sum(${products.soldCount}), 0)::int`,
    })
    .from(products);

  const [reviewAgg] = await db
    .select({
      count: sql<number>`count(*)::int`,
      avg: sql<number>`coalesce(avg(${reviews.rating}), 0)`,
      pending: sql<number>`count(*) filter (where ${reviews.verified} = false)::int`,
    })
    .from(reviews);

  const lowStock = await db
    .select({
      id: products.id,
      title: products.title,
      slug: products.slug,
      stock: products.stock,
      coverImage: products.coverImage,
      platform: products.platform,
    })
    .from(products)
    .where(lte(products.stock, 20))
    .orderBy(products.stock)
    .limit(6);

  const topRated = await db
    .select({
      id: products.id,
      title: products.title,
      slug: products.slug,
      ratingAvg: products.ratingAvg,
      ratingCount: products.ratingCount,
      coverImage: products.coverImage,
      soldCount: products.soldCount,
      price: products.price,
    })
    .from(products)
    .orderBy(desc(products.ratingAvg), desc(products.ratingCount))
    .limit(6);

  const recentOrders = await db
    .select({
      id: orders.id,
      orderNumber: orders.orderNumber,
      fullName: orders.fullName,
      email: orders.email,
      total: orders.total,
      status: orders.status,
      items: orders.items,
      createdAt: orders.createdAt,
    })
    .from(orders)
    .orderBy(desc(orders.createdAt))
    .limit(6);

  const genreSplit = await db
    .select({ genre: products.genre, count: sql<number>`count(*)::int` })
    .from(products)
    .groupBy(products.genre)
    .orderBy(desc(sql`count(*)`));

  return {
    orders: orderAgg ?? { count: 0, revenue: 0, discount: 0, units: 0 },
    products: productAgg ?? { count: 0, stock: 0, featured: 0, sold: 0 },
    reviews: {
      count: reviewAgg?.count ?? 0,
      avg: Math.round(Number(reviewAgg?.avg ?? 0) * 10) / 10,
      pending: reviewAgg?.pending ?? 0,
    },
    lowStock,
    topRated,
    recentOrders,
    genreSplit,
  };
}

async function ensureData() {
  const [row] = await db.select({ count: sql<number>`count(*)::int` }).from(products);
  if ((row?.count ?? 0) === 0) {
    const { ensureSeeded } = await import("./seed");
    await ensureSeeded();
  }
}

export async function getAdminProducts() {
  await ensureData();
  return db.select().from(products).orderBy(desc(products.featured), products.sortOrder);
}

export async function getAdminOrders() {
  return db.select().from(orders).orderBy(desc(orders.createdAt));
}

export async function getAdminReviews() {
  await ensureData();
  return db
    .select({
      id: reviews.id,
      productSlug: reviews.productSlug,
      author: reviews.author,
      location: reviews.location,
      rating: reviews.rating,
      title: reviews.title,
      body: reviews.body,
      verified: reviews.verified,
      helpful: reviews.helpful,
      createdAt: reviews.createdAt,
      productTitle: products.title,
    })
    .from(reviews)
    .leftJoin(products, eq(products.slug, reviews.productSlug))
    .orderBy(desc(reviews.createdAt));
}
