import { NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { products } from "@/db/schema";
import { isAdmin } from "@/lib/admin";
import { refreshProductRating } from "@/lib/queries";

export const dynamic = "force-dynamic";

const PLATFORMS = ["PC", "PlayStation 5", "Xbox Series X", "Nintendo Switch"];

function slugify(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    .slice(0, 60);
}

function list(value: unknown, fallback: string[] = []) {
  if (Array.isArray(value)) return value.map(String).filter(Boolean);
  if (typeof value === "string") {
    return value
      .split(/[,|\n]/)
      .map((item) => item.trim())
      .filter(Boolean);
  }
  return fallback;
}

function number(value: unknown, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? Math.round(parsed) : fallback;
}

export async function GET() {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  }
  const rows = await db.select().from(products).orderBy(products.sortOrder);
  return NextResponse.json({ products: rows });
}

export async function POST(request: Request) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  }

  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const title = String(body.title ?? "").trim();
  if (title.length < 2) {
    return NextResponse.json({ error: "A title is required." }, { status: 400 });
  }

  const slug = slugify(String(body.slug ?? "") || title);
  const existing = await db.select({ id: products.id }).from(products).where(eq(products.slug, slug));
  if (existing.length) {
    return NextResponse.json({ error: "That slug already exists." }, { status: 409 });
  }

  const coverImage =
    String(body.coverImage ?? "").trim() ||
    `https://images.pexels.com/photos/10414000/pexels-photo-10414000.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=800`;
  const gallery = list(body.gallery, [coverImage]);
  const highlights = list(body.highlights, ["Curated by the Bha Khan counter team"]);
  const tags = list(body.tags, ["New"]);

  const [maxOrder] = await db
    .select({ value: products.sortOrder })
    .from(products)
    .orderBy(products.sortOrder)
    .limit(1);

  try {
    const [created] = await db
      .insert(products)
      .values({
        slug,
        title,
        tagline: String(body.tagline ?? "").trim() || "A new arrival on the Bha Khan shelves.",
        description: String(body.description ?? "").trim() || "Full write-up coming soon.",
        story:
          String(body.story ?? "").trim() ||
          "Our counter team is still playing this one through — check back shortly for the full review.",
        price: number(body.price, 2999),
        compareAtPrice: body.compareAtPrice ? number(body.compareAtPrice) : null,
        platform: PLATFORMS.includes(String(body.platform)) ? String(body.platform) : "PC",
        genre: String(body.genre ?? "Adventure").trim() || "Adventure",
        edition: String(body.edition ?? "Standard Edition").trim() || "Standard Edition",
        publisher: String(body.publisher ?? "Independent").trim() || "Independent",
        developer: String(body.developer ?? "Independent").trim() || "Independent",
        releaseYear: number(body.releaseYear, new Date().getFullYear()),
        rated: String(body.rated ?? "T — Teen").trim() || "T — Teen",
        players: String(body.players ?? "Single player").trim() || "Single player",
        playtime: String(body.playtime ?? "≈ 20 hours").trim() || "≈ 20 hours",
        stock: Math.max(0, number(body.stock, 10)),
        featured: Boolean(body.featured),
        isNew: body.isNew === undefined ? true : Boolean(body.isNew),
        collectionSlug: String(body.collectionSlug ?? "arcade-vault").trim() || "arcade-vault",
        coverImage,
        gallery: gallery.length ? gallery : [coverImage],
        highlights: highlights.length ? highlights : ["Curated by the Bha Khan counter team"],
        tags: tags.length ? tags : ["New"],
        soldCount: Math.max(0, number(body.soldCount, 0)),
        sortOrder: (maxOrder?.value ?? 0) + 1,
      })
      .returning();

    revalidatePath("/");
    revalidatePath("/shop");
    revalidatePath(`/product/${created.slug}`);
    return NextResponse.json({ product: created });
  } catch {
    return NextResponse.json({ error: "Could not create that product." }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  }

  const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
  const id = number(body.id, 0);
  if (!id) return NextResponse.json({ error: "Missing product id." }, { status: 400 });

  const patch: Record<string, unknown> = {};
  if (body.title !== undefined) patch.title = String(body.title).trim();
  if (body.tagline !== undefined) patch.tagline = String(body.tagline).trim();
  if (body.description !== undefined) patch.description = String(body.description).trim();
  if (body.story !== undefined) patch.story = String(body.story).trim();
  if (body.price !== undefined) patch.price = Math.max(0, number(body.price));
  if (body.compareAtPrice !== undefined) {
    patch.compareAtPrice = body.compareAtPrice ? number(body.compareAtPrice) : null;
  }
  if (body.platform !== undefined) patch.platform = String(body.platform);
  if (body.genre !== undefined) patch.genre = String(body.genre);
  if (body.edition !== undefined) patch.edition = String(body.edition);
  if (body.developer !== undefined) patch.developer = String(body.developer);
  if (body.publisher !== undefined) patch.publisher = String(body.publisher);
  if (body.releaseYear !== undefined) patch.releaseYear = number(body.releaseYear);
  if (body.stock !== undefined) patch.stock = Math.max(0, number(body.stock));
  if (body.featured !== undefined) patch.featured = Boolean(body.featured);
  if (body.isNew !== undefined) patch.isNew = Boolean(body.isNew);
  if (body.collectionSlug !== undefined) patch.collectionSlug = String(body.collectionSlug);
  if (body.coverImage !== undefined) patch.coverImage = String(body.coverImage).trim();
  if (body.highlights !== undefined) patch.highlights = list(body.highlights);
  if (body.tags !== undefined) patch.tags = list(body.tags);
  if (body.gallery !== undefined) patch.gallery = list(body.gallery);

  if (!Object.keys(patch).length) {
    return NextResponse.json({ error: "Nothing to update." }, { status: 400 });
  }

  try {
    const [updated] = await db.update(products).set(patch).where(eq(products.id, id)).returning();
    if (!updated) return NextResponse.json({ error: "Product not found." }, { status: 404 });
    revalidatePath("/");
    revalidatePath("/shop");
    revalidatePath(`/product/${updated.slug}`);
    return NextResponse.json({ product: updated });
  } catch {
    return NextResponse.json({ error: "Could not update that product." }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  }
  const id = number(new URL(request.url).searchParams.get("id"), 0);
  if (!id) return NextResponse.json({ error: "Missing product id." }, { status: 400 });

  const [removed] = await db.delete(products).where(eq(products.id, id)).returning();
  if (!removed) return NextResponse.json({ error: "Product not found." }, { status: 404 });

  revalidatePath("/");
  revalidatePath("/shop");
  return NextResponse.json({ ok: true });
}
