"use client";

import { useState, type FormEvent } from "react";

export function Newsletter() {
  const [email, setEmail] = useState("");
  const [done, setDone] = useState(false);

  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!email.includes("@")) return;
    setDone(true);
    setEmail("");
  };

  return (
    <div className="relative overflow-hidden rounded-3xl border border-edge bg-gradient-to-br from-panel via-ink to-void p-8 sm:p-14">
      <div className="pointer-events-none absolute -right-20 -top-24 size-72 rounded-full bg-gold/10 blur-[90px]" />
      <div className="pointer-events-none absolute -bottom-24 -left-20 size-72 rounded-full bg-violet/10 blur-[90px]" />
      <div className="relative grid gap-8 lg:grid-cols-[1.1fr_1fr] lg:items-center">
        <div>
          <p className="eyebrow text-gold">The Dispatch</p>
          <h2 className="mt-3 font-display text-4xl leading-[1.05] sm:text-5xl">
            One email a week.
            <br />
            <span className="gold-text">Only the good stuff.</span>
          </h2>
          <p className="mt-4 max-w-md text-sm leading-relaxed text-mist">
            Release dates we actually trust, price drops worth acting on, and a staff review that
            isn&apos;t a press release. Unsubscribe in one click.
          </p>
        </div>

        <div>
          {done ? (
            <div className="rounded-2xl border border-gold/30 bg-gold/10 p-6">
              <p className="font-display text-2xl text-gold-soft">You&apos;re on the list.</p>
              <p className="mt-2 text-sm text-mist">
                Check your inbox for a welcome code worth 10% off your first order.
              </p>
            </div>
          ) : (
            <form onSubmit={submit} className="flex flex-col gap-3 sm:flex-row">
              <input
                type="email"
                required
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                placeholder="you@example.com"
                className="w-full rounded-full border border-edge bg-void/60 px-5 py-3.5 text-sm outline-none transition focus:border-gold/60 placeholder:text-mist/60"
                aria-label="Email address"
              />
              <button
                type="submit"
                className="shrink-0 rounded-full bg-bone px-7 py-3.5 text-sm font-bold text-void transition hover:bg-gold-soft"
              >
                Subscribe
              </button>
            </form>
          )}
          <p className="mt-3 text-[11px] text-mist">
            Join 42,800 players. No spam, no resale of your data, ever.
          </p>
        </div>
      </div>
    </div>
  );
}
