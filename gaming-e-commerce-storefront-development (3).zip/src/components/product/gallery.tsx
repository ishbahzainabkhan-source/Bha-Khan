"use client";

import { useState } from "react";
import { cx } from "@/lib/format";

export function Gallery({
  images,
  title,
  badge,
}: {
  images: string[];
  title: string;
  badge?: string;
}) {
  const list = images.length ? images : ["/images/hero.jpg"];
  const [index, setIndex] = useState(0);
  const [zoom, setZoom] = useState(false);
  const [origin, setOrigin] = useState("50% 50%");

  const go = (next: number) => setIndex((next + list.length) % list.length);

  return (
    <div className="lg:sticky lg:top-28">
      <div
        className="group relative aspect-[4/5] w-full overflow-hidden rounded-3xl border border-edge bg-panel"
        onMouseMove={(event) => {
          const rect = event.currentTarget.getBoundingClientRect();
          setOrigin(
            `${((event.clientX - rect.left) / rect.width) * 100}% ${
              ((event.clientY - rect.top) / rect.height) * 100
            }%`,
          );
        }}
        onMouseEnter={() => setZoom(true)}
        onMouseLeave={() => setZoom(false)}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          key={list[index]}
          src={list[index]}
          alt={`${title} — image ${index + 1}`}
          className={cx(
            "size-full object-cover transition-transform duration-700 ease-out",
            zoom ? "scale-[1.35]" : "scale-100",
          )}
          style={{ transformOrigin: origin }}
        />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-void/60 via-transparent to-transparent" />

        {badge ? (
          <span className="absolute left-4 top-4 rounded-full bg-bone px-3 py-1 text-[10px] font-bold tracking-[0.18em] text-void uppercase">
            {badge}
          </span>
        ) : null}

        {list.length > 1 && (
          <>
            <button
              type="button"
              onClick={() => go(index - 1)}
              className="absolute left-3 top-1/2 grid size-10 -translate-y-1/2 place-items-center rounded-full border border-white/15 bg-black/50 text-bone opacity-0 backdrop-blur transition group-hover:opacity-100 hover:bg-black/80"
              aria-label="Previous image"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="m15 6-6 6 6 6" />
              </svg>
            </button>
            <button
              type="button"
              onClick={() => go(index + 1)}
              className="absolute right-3 top-1/2 grid size-10 -translate-y-1/2 place-items-center rounded-full border border-white/15 bg-black/50 text-bone opacity-0 backdrop-blur transition group-hover:opacity-100 hover:bg-black/80"
              aria-label="Next image"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="m9 6 6 6-6 6" />
              </svg>
            </button>
            <div className="absolute bottom-4 left-1/2 flex -translate-x-1/2 gap-1.5">
              {list.map((image, dot) => (
                <button
                  key={image + dot}
                  type="button"
                  onClick={() => setIndex(dot)}
                  aria-label={`Go to image ${dot + 1}`}
                  className={cx(
                    "h-1 rounded-full transition-all duration-500",
                    dot === index ? "w-7 bg-gold" : "w-3 bg-bone/30 hover:bg-bone/60",
                  )}
                />
              ))}
            </div>
          </>
        )}
      </div>

      {list.length > 1 && (
        <div className="mt-4 grid grid-cols-4 gap-3">
          {list.map((image, thumb) => (
            <button
              key={image + thumb}
              type="button"
              onClick={() => setIndex(thumb)}
              className={cx(
                "relative aspect-square overflow-hidden rounded-xl border transition",
                thumb === index
                  ? "border-gold ring-1 ring-gold/40"
                  : "border-edge opacity-60 hover:opacity-100",
              )}
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={image} alt="" loading="lazy" className="size-full object-cover" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
