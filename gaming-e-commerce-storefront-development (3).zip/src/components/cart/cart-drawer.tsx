"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect } from "react";
import { useCart } from "./cart-provider";
import { formatPrice, cx } from "@/lib/format";

const FREE_SHIPPING_THRESHOLD = 7500;

export function CartDrawer() {
  const { items, isOpen, closeCart, setQuantity, removeItem, subtotal, savings, count } = useCart();
  const pathname = usePathname();

  useEffect(() => {
    closeCart();
  }, [pathname, closeCart]);

  const remaining = Math.max(0, FREE_SHIPPING_THRESHOLD - subtotal);
  const progress = Math.min(100, (subtotal / FREE_SHIPPING_THRESHOLD) * 100);

  return (
    <div
      className={cx("fixed inset-0 z-[90]", isOpen ? "pointer-events-auto" : "pointer-events-none")}
      aria-hidden={!isOpen}
    >
      <button
        type="button"
        aria-label="Close cart"
        onClick={closeCart}
        className={cx(
          "absolute inset-0 bg-black/70 backdrop-blur-sm transition-opacity duration-500",
          isOpen ? "opacity-100" : "opacity-0",
        )}
        tabIndex={isOpen ? 0 : -1}
      />

      <aside
        role="dialog"
        aria-modal="true"
        aria-label="Shopping cart"
        className={cx(
          "absolute right-0 top-0 flex h-full w-full max-w-[440px] flex-col border-l border-edge bg-ink shadow-[0_0_80px_rgba(0,0,0,0.8)] transition-transform duration-[520ms] ease-[cubic-bezier(0.22,1,0.36,1)]",
          isOpen ? "translate-x-0" : "translate-x-full",
        )}
      >
        <header className="flex items-center justify-between border-b border-edge px-6 py-5">
          <div>
            <p className="eyebrow text-gold">Your bag</p>
            <h2 className="font-display text-2xl">
              {count} {count === 1 ? "title" : "titles"}
            </h2>
          </div>
          <button
            type="button"
            onClick={closeCart}
            className="grid size-10 place-items-center rounded-full border border-edge text-mist transition hover:border-gold/50 hover:text-bone"
            aria-label="Close cart"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M18 6 6 18M6 6l12 12" />
            </svg>
          </button>
        </header>

        {items.length > 0 && (
          <div className="border-b border-edge px-6 py-4">
            <p className="text-xs text-mist">
              {remaining > 0 ? (
                <>
                  You&apos;re <span className="text-gold-soft">{formatPrice(remaining)}</span> away from
                  free express delivery
                </>
              ) : (
                <span className="text-gold-soft">Free express delivery unlocked</span>
              )}
            </p>
            <div className="mt-2 h-1 w-full overflow-hidden rounded-full bg-edge">
              <div
                className="h-full rounded-full bg-gradient-to-r from-gold/60 via-gold to-gold-soft transition-[width] duration-700"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        )}

        <div className="flex-1 overflow-y-auto px-6 py-5">
          {items.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center gap-4 text-center">
              <div className="grid size-16 place-items-center rounded-full border border-edge text-mist">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                  <path d="M3 5h2l2.4 11.2a2 2 0 0 0 2 1.6h7.5a2 2 0 0 0 2-1.6L20.5 8H6" />
                  <circle cx="10" cy="20" r="1.4" />
                  <circle cx="17" cy="20" r="1.4" />
                </svg>
              </div>
              <div>
                <p className="font-display text-xl">Your bag is empty</p>
                <p className="mt-1 text-sm text-mist">
                  Pick up where the adventure left off.
                </p>
              </div>
              <Link
                href="/shop"
                onClick={closeCart}
                className="rounded-full bg-bone px-6 py-2.5 text-sm font-semibold text-void transition hover:bg-gold-soft"
              >
                Browse the shelves
              </Link>
            </div>
          ) : (
            <ul className="space-y-5">
              {items.map((item) => (
                <li key={item.slug} className="flex gap-4">
                  <Link
                    href={`/product/${item.slug}`}
                    onClick={closeCart}
                    className="relative size-24 shrink-0 overflow-hidden rounded-xl border border-edge bg-panel"
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={item.coverImage}
                      alt={item.title}
                      className="size-full object-cover"
                      loading="lazy"
                    />
                  </Link>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-start justify-between gap-3">
                      <Link
                        href={`/product/${item.slug}`}
                        onClick={closeCart}
                        className="font-display text-lg leading-tight hover:text-gold-soft"
                      >
                        {item.title}
                      </Link>
                      <button
                        type="button"
                        onClick={() => removeItem(item.slug)}
                        className="text-mist transition hover:text-rose-400"
                        aria-label={`Remove ${item.title}`}
                      >
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M18 6 6 18M6 6l12 12" />
                        </svg>
                      </button>
                    </div>
                    <p className="mt-0.5 text-xs text-mist">
                      {item.platform} · {item.edition}
                    </p>
                    <div className="mt-3 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-1 rounded-full border border-edge p-1">
                        <button
                          type="button"
                          onClick={() => setQuantity(item.slug, item.quantity - 1)}
                          className="grid size-7 place-items-center rounded-full text-mist transition hover:bg-panel hover:text-bone"
                          aria-label="Decrease quantity"
                        >
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                            <path d="M5 12h14" />
                          </svg>
                        </button>
                        <span className="min-w-6 text-center text-sm tabular-nums">{item.quantity}</span>
                        <button
                          type="button"
                          onClick={() => setQuantity(item.slug, item.quantity + 1)}
                          disabled={item.quantity >= item.stock}
                          className="grid size-7 place-items-center rounded-full text-mist transition hover:bg-panel hover:text-bone disabled:opacity-30"
                          aria-label="Increase quantity"
                        >
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                            <path d="M12 5v14M5 12h14" />
                          </svg>
                        </button>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-semibold tabular-nums">
                          {formatPrice(item.price * item.quantity)}
                        </p>
                        {item.compareAtPrice ? (
                          <p className="text-[11px] text-mist line-through tabular-nums">
                            {formatPrice(item.compareAtPrice * item.quantity)}
                          </p>
                        ) : null}
                      </div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {items.length > 0 && (
          <footer className="border-t border-edge px-6 py-5">
            <div className="space-y-1.5 text-sm">
              <div className="flex justify-between text-mist">
                <span>Subtotal</span>
                <span className="tabular-nums text-bone">{formatPrice(subtotal)}</span>
              </div>
              {savings > 0 && (
                <div className="flex justify-between text-emerald-400">
                  <span>You save</span>
                  <span className="tabular-nums">−{formatPrice(savings)}</span>
                </div>
              )}
              <div className="flex justify-between text-mist">
                <span>Delivery</span>
                <span className="tabular-nums text-bone">
                  {remaining > 0 ? formatPrice(599) : "Free"}
                </span>
              </div>
            </div>
            <Link
              href="/checkout"
              onClick={closeCart}
              className="mt-5 flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-gold-soft via-gold to-gold-soft bg-[length:200%_100%] px-6 py-3.5 text-sm font-bold tracking-wide text-void transition-[background-position] duration-700 hover:bg-right"
            >
              Secure checkout
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M5 12h14M13 6l6 6-6 6" />
              </svg>
            </Link>
            <button
              type="button"
              onClick={closeCart}
              className="mt-2 w-full rounded-full px-6 py-2.5 text-xs text-mist transition hover:text-bone"
            >
              Continue shopping
            </button>
          </footer>
        )}
      </aside>
    </div>
  );
}
