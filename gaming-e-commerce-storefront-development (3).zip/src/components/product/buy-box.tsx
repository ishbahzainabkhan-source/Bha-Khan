"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import type { Product } from "@/db/schema";
import { useCart } from "@/components/cart/cart-provider";
import { cx, discountPercent, formatPrice } from "@/lib/format";

const EDITION_UPGRADES = [
  { key: "standard", label: "Standard", delta: 0, note: "Base game" },
  { key: "deluxe", label: "Deluxe", delta: 1500, note: "+ season pass & art book" },
  { key: "collector", label: "Collector", delta: 4500, note: "+ statue, vinyl, map" },
];

export function BuyBox({ product }: { product: Product }) {
  const { addItem } = useCart();
  const router = useRouter();
  const [quantity, setQuantity] = useState(1);
  const [edition, setEdition] = useState("standard");

  const upgrade = EDITION_UPGRADES.find((item) => item.key === edition) ?? EDITION_UPGRADES[0];
  const unitPrice = product.price + upgrade.delta;
  const compareAt = product.compareAtPrice ? product.compareAtPrice + upgrade.delta : null;
  const off = discountPercent(unitPrice, compareAt);
  const soldOut = product.stock <= 0;

  const payload = {
    slug: `${product.slug}${edition === "standard" ? "" : `--${edition}`}`,
    title: product.title,
    price: unitPrice,
    compareAtPrice: compareAt,
    coverImage: product.coverImage,
    platform: product.platform,
    edition: edition === "standard" ? product.edition : `${upgrade.label} Edition`,
    stock: product.stock,
  };

  return (
    <div className="rounded-3xl border border-edge bg-panel/40 p-6 backdrop-blur">
      <div className="flex flex-wrap items-end gap-x-4 gap-y-2">
        <span className="font-display text-5xl leading-none tabular-nums">
          {formatPrice(unitPrice)}
        </span>
        {compareAt ? (
          <span className="text-lg text-mist line-through tabular-nums">
            {formatPrice(compareAt)}
          </span>
        ) : null}
        {off > 0 && (
          <span className="rounded-full bg-rose-500 px-2.5 py-1 text-[11px] font-bold text-white">
            Save {off}%
          </span>
        )}
      </div>
      <p className="mt-2 text-xs text-mist">
        Or 4 interest-free payments of {formatPrice(Math.round(unitPrice / 4))}. Taxes calculated at
        checkout.
      </p>

      <div className="mt-6">
        <p className="eyebrow text-gold">Edition</p>
        <div className="mt-3 grid gap-2">
          {EDITION_UPGRADES.map((item) => (
            <button
              key={item.key}
              type="button"
              onClick={() => setEdition(item.key)}
              className={cx(
                "flex items-center justify-between rounded-xl border px-4 py-3 text-left transition",
                edition === item.key
                  ? "border-gold/60 bg-gold/10"
                  : "border-edge hover:border-mist/40",
              )}
            >
              <span>
                <span className="block text-sm font-semibold">{item.label}</span>
                <span className="block text-[11px] text-mist">{item.note}</span>
              </span>
              <span className="text-sm tabular-nums">
                {item.delta === 0 ? "Included" : `+${formatPrice(item.delta)}`}
              </span>
            </button>
          ))}
        </div>
      </div>

      <div className="mt-6 flex items-center gap-4">
        <div className="flex items-center gap-1 rounded-full border border-edge p-1">
          <button
            type="button"
            onClick={() => setQuantity((value) => Math.max(1, value - 1))}
            className="grid size-9 place-items-center rounded-full text-mist transition hover:bg-void hover:text-bone"
            aria-label="Decrease quantity"
          >
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4">
              <path d="M5 12h14" />
            </svg>
          </button>
          <span className="min-w-8 text-center tabular-nums">{quantity}</span>
          <button
            type="button"
            onClick={() => setQuantity((value) => Math.min(product.stock || 1, value + 1))}
            className="grid size-9 place-items-center rounded-full text-mist transition hover:bg-void hover:text-bone"
            aria-label="Increase quantity"
          >
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4">
              <path d="M12 5v14M5 12h14" />
            </svg>
          </button>
        </div>
        <p className="text-xs text-mist">
          {soldOut ? (
            <span className="text-rose-400">Out of stock — join the waitlist</span>
          ) : product.stock <= 10 ? (
            <span className="text-amber-400">Only {product.stock} copies left in the shop</span>
          ) : (
            <>
              <span className="text-emerald-400">In stock</span> · ships within 24 hours
            </>
          )}
        </p>
      </div>

      <div className="mt-5 grid gap-3">
        <button
          type="button"
          disabled={soldOut}
          onClick={() => addItem(payload, quantity)}
          className="group flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-gold-soft via-gold to-gold-soft bg-[length:200%_100%] px-8 py-4 text-sm font-bold tracking-wide text-void transition-[background-position] duration-700 hover:bg-right disabled:cursor-not-allowed disabled:bg-none disabled:bg-edge disabled:text-mist"
        >
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M3 5h2l2.4 11.2a2 2 0 0 0 2 1.6h7.5a2 2 0 0 0 2-1.6L20.5 8H6" />
          </svg>
          {soldOut ? "Sold out" : "Add to bag"}
        </button>
        <button
          type="button"
          disabled={soldOut}
          onClick={() => {
            addItem(payload, quantity);
            router.push("/checkout");
          }}
          className="w-full rounded-full border border-edge px-8 py-3.5 text-sm font-semibold text-bone transition hover:border-gold/50 disabled:opacity-40"
        >
          Buy it now
        </button>
      </div>

      <ul className="mt-6 grid gap-2.5 border-t border-edge pt-5 text-xs text-mist">
        {[
          "Free tracked express delivery over $75",
          "30-day returns on unopened copies",
          "Price-match promise for 14 days",
          "Instant digital keys delivered by email",
        ].map((item) => (
          <li key={item} className="flex items-center gap-2">
            <svg
              width="13"
              height="13"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.6"
              className="text-gold"
            >
              <path d="m4 12 5 5L20 6" />
            </svg>
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
}
