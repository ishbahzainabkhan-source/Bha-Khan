import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { Reveal } from "@/components/ui/reveal";
import { formatDate, formatPrice } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Order confirmed",
};

export default async function OrderPage({
  params,
}: {
  params: Promise<{ orderNumber: string }>;
}) {
  const { orderNumber } = await params;
  const rows = await db
    .select()
    .from(orders)
    .where(eq(orders.orderNumber, decodeURIComponent(orderNumber)))
    .limit(1);

  const order = rows[0];
  if (!order) notFound();

  const eta = new Date(order.createdAt.getTime() + 1000 * 60 * 60 * 24 * 3);

  return (
    <div className="mx-auto max-w-4xl px-5 py-16 sm:px-8">
      <Reveal>
        <div className="text-center">
          <span className="mx-auto grid size-16 place-items-center rounded-full border border-gold/40 bg-gold/10 text-gold">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="m4 12 5 5L20 6" />
            </svg>
          </span>
          <p className="eyebrow mt-6 text-gold">Order {order.orderNumber}</p>
          <h1 className="mt-4 font-display text-[clamp(2.5rem,6vw,4.5rem)] leading-[0.95]">
            Thank you, {order.fullName.split(" ")[0]}.
          </h1>
          <p className="mx-auto mt-4 max-w-lg text-sm leading-relaxed text-mist sm:text-base">
            Your order is confirmed and a receipt is on its way to{" "}
            <span className="text-bone">{order.email}</span>.{" "}
            {order.deliveryMethod === "digital"
              ? "Your keys will arrive by email within the minute."
              : `Estimated delivery ${formatDate(eta)}.`}
          </p>
        </div>
      </Reveal>

      <Reveal delay={120}>
        <div className="mt-12 overflow-hidden rounded-3xl border border-edge bg-panel/30">
          <div className="grid gap-6 border-b border-edge p-6 sm:grid-cols-3 sm:p-8">
            <div>
              <p className="eyebrow text-mist">Placed</p>
              <p className="mt-2 text-sm">{formatDate(order.createdAt)}</p>
            </div>
            <div>
              <p className="eyebrow text-mist">Delivery</p>
              <p className="mt-2 text-sm capitalize">{order.deliveryMethod}</p>
              {order.deliveryMethod === "express" && order.address ? (
                <p className="mt-1 text-xs text-mist">
                  {order.address}, {order.city} {order.postalCode}, {order.country}
                </p>
              ) : null}
            </div>
            <div>
              <p className="eyebrow text-mist">Status</p>
              <p className="mt-2 inline-flex items-center gap-2 text-sm">
                <span className="size-1.5 animate-pulse rounded-full bg-emerald-400" />
                Confirmed · packing
              </p>
            </div>
          </div>

          <ul className="divide-y divide-edge">
            {order.items.map((item) => (
              <li key={item.slug} className="flex items-center gap-4 p-6">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={item.coverImage}
                  alt={item.title}
                  className="size-20 rounded-xl border border-edge object-cover"
                />
                <div className="min-w-0 flex-1">
                  <Link
                    href={`/product/${item.slug.split("--")[0]}`}
                    className="font-display text-xl hover:text-gold-soft"
                  >
                    {item.title}
                  </Link>
                  <p className="text-xs text-mist">
                    {item.edition} · {item.platform} · Qty {item.quantity}
                  </p>
                </div>
                <span className="tabular-nums">{formatPrice(item.price * item.quantity)}</span>
              </li>
            ))}
          </ul>

          <dl className="space-y-2 border-t border-edge p-6 text-sm sm:p-8">
            <div className="flex justify-between">
              <dt className="text-mist">Subtotal</dt>
              <dd className="tabular-nums">{formatPrice(order.subtotal)}</dd>
            </div>
            {order.discount > 0 && (
              <div className="flex justify-between text-emerald-400">
                <dt>Promo {order.promoCode}</dt>
                <dd className="tabular-nums">−{formatPrice(order.discount)}</dd>
              </div>
            )}
            <div className="flex justify-between">
              <dt className="text-mist">Delivery</dt>
              <dd className="tabular-nums">
                {order.shipping === 0 ? "Free" : formatPrice(order.shipping)}
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-mist">Tax</dt>
              <dd className="tabular-nums">{formatPrice(order.tax)}</dd>
            </div>
            <div className="flex items-end justify-between border-t border-edge pt-4">
              <dt className="font-display text-2xl">Total paid</dt>
              <dd className="font-display text-3xl tabular-nums">{formatPrice(order.total)}</dd>
            </div>
          </dl>
        </div>
      </Reveal>

      <Reveal delay={200}>
        <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <Link
            href="/shop"
            className="rounded-full bg-bone px-8 py-3.5 text-sm font-bold text-void transition hover:bg-gold-soft"
          >
            Continue shopping
          </Link>
          <Link
            href="/"
            className="rounded-full border border-edge px-8 py-3.5 text-sm font-semibold transition hover:border-gold/50"
          >
            Back to the shop front
          </Link>
        </div>
      </Reveal>
    </div>
  );
}
