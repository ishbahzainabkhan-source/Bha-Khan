import { readFile } from "node:fs/promises";
import path from "node:path";

export const dynamic = "force-dynamic";

const COVERS = [
  "eclipse-protocol.jpg",
  "ashen-crown.jpg",
  "neon-drift.jpg",
  "stellar-cartographer.jpg",
  "verdant-hollow.jpg",
  "iron-vanguard.jpg",
  "midnight-syndicate.jpg",
  "tidebreaker.jpg",
];

async function dataUri(relative: string) {
  try {
    const buffer = await readFile(path.join(process.cwd(), "public", relative));
    const ext = path.extname(relative).slice(1).toLowerCase();
    const mime = ext === "png" ? "image/png" : "image/jpeg";
    return `data:${mime};base64,${buffer.toString("base64")}`;
  } catch {
    return "";
  }
}

/**
 * Returns a fully self-contained index.html: the whole storefront + admin panel
 * with every local image inlined as a base64 data URI. Upload this single file
 * to a GitHub repository root and enable Pages — no images folder required.
 */
export async function GET() {
  let html: string;
  try {
    html = await readFile(path.join(process.cwd(), "public", "index.html"), "utf8");
  } catch {
    return new Response("index.html not found", { status: 404 });
  }

  const entries: string[] = [];

  const hero = await dataUri("images/hero.jpg");
  if (hero) {
    entries.push(`"hero.jpg":"${hero}"`);
    html = html.replace('src="images/hero.jpg"', 'src="' + hero + '"');
  }

  for (const file of COVERS) {
    const uri = await dataUri(`images/covers/${file}`);
    if (uri) entries.push(`"covers/${file}":"${uri}"`);
  }

  // Route the runtime LOCAL() helper through the inlined map.
  html = html.replace(
    "const LOCAL = f => `images/covers/${f}`;",
    "const LOCAL = f => (self.__BKIMAGES && self.__BKIMAGES['covers/'+f]) || `images/covers/${f}`;",
  );

  const inject = `<script>self.__BKIMAGES={${entries.join(",")}};</script>`;
  html = html.replace("</head>", `${inject}\n</head>`);

  return new Response(html, {
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Content-Disposition": 'attachment; filename="index.html"',
      "Cache-Control": "no-store",
    },
  });
}
