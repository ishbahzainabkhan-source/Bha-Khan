import Link from "next/link";

const COLUMNS = [
  {
    title: "Shop",
    links: [
      { label: "All games", href: "/shop" },
      { label: "New releases", href: "/shop?sort=newest" },
      { label: "On sale", href: "/shop?onSale=1" },
      { label: "Best sellers", href: "/shop?sort=bestselling" },
      { label: "Collections", href: "/collections" },
    ],
  },
  {
    title: "Platforms",
    links: [
      { label: "PC", href: "/shop?platform=PC" },
      { label: "PlayStation 5", href: "/shop?platform=PlayStation+5" },
      { label: "Xbox Series X", href: "/shop?platform=Xbox+Series+X" },
      { label: "Nintendo Switch", href: "/shop?platform=Nintendo+Switch" },
    ],
  },
  {
    title: "Service",
    links: [
      { label: "Delivery & returns", href: "/shop" },
      { label: "Price-match promise", href: "/shop" },
      { label: "Gift cards", href: "/shop" },
      { label: "Contact the shop", href: "/shop" },
      { label: "Back office / admin", href: "/admin" },
    ],
  },
];

export function SiteFooter() {
  return (
    <footer className="relative mt-24 border-t border-edge bg-ink">
      <div className="mx-auto max-w-[1400px] px-5 py-16 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_2fr]">
          <div>
            <Link href="/" className="flex items-center gap-3">
              <span className="grid size-10 place-items-center rounded-xl bg-gradient-to-br from-gold-soft via-gold to-[#8a6425] text-void">
                <span className="font-display text-xl leading-none">B</span>
              </span>
              <span className="font-display text-2xl">
                Bha <span className="gold-text">Khan</span>
              </span>
            </Link>
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-mist">
              A independent game merchant since 2011. We stock what we play, we write our own
              recommendations, and we ship worldwide in recycled packaging.
            </p>
            <div className="mt-6 flex gap-3">
              {["Instagram", "Discord", "YouTube", "Bluesky"].map((item) => (
                <span
                  key={item}
                  className="rounded-full border border-edge px-3 py-1.5 text-[11px] tracking-wide text-mist"
                >
                  {item}
                </span>
              ))}
            </div>
          </div>

          <div className="grid gap-8 sm:grid-cols-3">
            {COLUMNS.map((column) => (
              <div key={column.title}>
                <p className="eyebrow text-gold">{column.title}</p>
                <ul className="mt-4 space-y-2.5">
                  {column.links.map((link) => (
                    <li key={link.label}>
                      <Link
                        href={link.href}
                        className="text-sm text-mist transition hover:text-bone"
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-14 flex flex-col gap-4 border-t border-edge pt-6 text-xs text-mist sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} Bha Khan Game Merchants. All rights reserved.</p>
          <p className="flex flex-wrap gap-5">
            <span>Privacy</span>
            <span>Terms</span>
            <span>Accessibility</span>
            <span className="text-gold-soft">Demo storefront — no real payments taken</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
