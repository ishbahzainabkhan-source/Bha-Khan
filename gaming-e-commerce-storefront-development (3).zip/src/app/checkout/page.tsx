import type { Metadata } from "next";
import { CheckoutClient } from "./checkout-client";

export const metadata: Metadata = {
  title: "Checkout",
  description: "Secure checkout at Bha Khan Game Merchants.",
};

export default function CheckoutPage() {
  return (
    <div className="mx-auto max-w-[1400px] px-5 py-14 sm:px-8">
      <header className="mb-10">
        <p className="eyebrow text-gold">Almost there</p>
        <h1 className="mt-3 font-display text-[clamp(2.5rem,5vw,4rem)] leading-[0.95]">Checkout</h1>
      </header>
      <CheckoutClient />
    </div>
  );
}
