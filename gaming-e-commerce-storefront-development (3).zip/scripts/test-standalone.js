// Runtime smoke test for public/index.html using a minimal DOM shim.
const fs = require("fs");
const vm = require("vm");

const html = fs.readFileSync("public/index.html", "utf8");
const code = html.match(/<script>([\s\S]*?)<\/script>/)[1];

function el(id) {
  const classes = new Set();
  return {
    id,
    tagName: "DIV",
    innerHTML: "",
    textContent: "",
    value: "",
    style: {},
    dataset: {},
    children: [],
    selectionStart: 0,
    classList: {
      add: (...c) => c.forEach((x) => classes.add(x)),
      remove: (...c) => c.forEach((x) => classes.delete(x)),
      toggle: (c, f) => (f === undefined ? (classes.has(c) ? classes.delete(c) : classes.add(c)) : f ? classes.add(c) : classes.delete(c)),
      contains: (c) => classes.has(c),
    },
    getAttribute: () => null,
    setAttribute: () => {},
    addEventListener: () => {},
    focus: () => {},
    setSelectionRange: () => {},
    querySelector: () => el(id + "/q"),
    querySelectorAll: () => [],
    click: () => {},
  };
}

const byId = new Map();
const bySel = new Map();
const store = new Map();
const storage = {
  getItem: (k) => (store.has(k) ? store.get(k) : null),
  setItem: (k, v) => store.set(k, String(v)),
  removeItem: (k) => store.delete(k),
};

const document = {
  activeElement: null,
  body: el("body"),
  getElementById: (id) => {
    if (!byId.has(id)) byId.set(id, el(id));
    return byId.get(id);
  },
  querySelector: (s) => { if (!bySel.has(s)) bySel.set(s, el(s)); return bySel.get(s); },
  querySelectorAll: () => [],
  createElement: (t) => el(t),
  confirm: () => true,
};

const sandbox = {
  console,
  document,
  localStorage: storage,
  sessionStorage: storage,
  location: { hash: "#/", href: "" },
  navigator: { userAgent: "node" },
  window: null,
  IntersectionObserver: class {
    observe() {}
    unobserve() {}
    disconnect() {}
  },
  Blob: class {},
  URL: { createObjectURL: () => "" },
  FileReader: class {
    readAsText() {}
  },
  setTimeout,
  clearTimeout,
  requestAnimationFrame: (f) => f(),
  Math, Date, JSON, Number, String, Array, Object, RegExp, Boolean, Set, Map, Promise, Error, encodeURIComponent, decodeURIComponent, parseInt, parseFloat, isNaN, URLSearchParams,
};
sandbox.window = {
  addEventListener: () => {},
  scrollTo: () => {},
  innerWidth: 1440,
  location: sandbox.location,
};
sandbox.globalThis = sandbox;

vm.createContext(sandbox);
vm.runInContext(code, sandbox, { filename: "standalone.js" });

const routes = [
  ["#/", "home", ["Games worth", "Featured collections", "Curator's picks"]],
  ["#/shop", "shop", ["Every game we stock", "Curator"]],
  ["#/shop?platform=PC&sort=price-asc", "shop-filtered", ["Showing"]],
  ["#/shop?sale=1", "shop-sale", ["Showing"]],
  ["#/collections", "collections", ["Galactic Frontier", "Cozy Corner"]],
  ["#/collections/cozy-corner", "collection", ["Cozy Corner"]],
  ["#/product/ashen-crown", "product", ["Ashen Crown", "What players say", "Specifications"]],
  ["#/product/eclipse-protocol", "product2", ["Eclipse Protocol"]],
  ["#/checkout", "checkout-empty", ["Your bag is empty"]],
  ["#/orders", "orders-lookup", ["orders"]],
  ["#/orders/BKNOPE1", "order-missing", ["shelf is empty"]],
  ["#/admin", "admin-login", ["Back office", "khan2026"]],
  ["#/nope", "fallback-home", ["Games worth"]],
];

let pass = 0;
for (const [hash, name, expects] of routes) {
  sandbox.location.hash = hash;
  vm.runInContext("route()", sandbox);
  const out = bySel.get("#app").innerHTML;
  const missing = expects.filter((e) => !out.includes(e));
  if (missing.length) {
    console.log(`❌ ${name} (${hash}) — missing: ${missing.join(" | ")}`);
  } else {
    console.log(`✅ ${name.padEnd(16)} ${String(out.length).padStart(6)} bytes`);
    pass++;
  }
}

// Admin login + every admin tab
vm.runInContext(`ADMIN=true; route()`, sandbox);
for (const tab of ["dash", "cat", "ord", "rev", "data"]) {
  sandbox.location.hash = "#/admin";
  vm.runInContext(`ATAB='${tab}'; route()`, sandbox);
  const out = bySel.get("#app").innerHTML;
  const ok = out.length > 500 && !out.includes("undefined") || tab === "ord";
  console.log(`${ok && out.length > 500 ? "✅" : "⚠️ "} admin:${tab.padEnd(6)} ${String(out.length).padStart(6)} bytes`);
  if (/>\s*undefined\s*</.test(out)) console.log(`   ⚠️  raw "undefined" leaked into admin:${tab}`);
}

// Cart + order placement flow
vm.runInContext(
  `addToCart(DB.products[0],2,"deluxe"); addToCart(DB.products[4],1,"standard");`,
  sandbox,
);
const cartCount = vm.runInContext("cartCount()", sandbox);
const sub = vm.runInContext("cartSub()", sandbox);
console.log(`${cartCount === 3 ? "✅" : "❌"} cart count = ${cartCount}, subtotal = ${sub}`);

const before = vm.runInContext("ORDERS.length", sandbox);
vm.runInContext(
  `Object.assign(CHECKOUT.form,{name:"Test Player",email:"t@e.com",address:"1 Row",city:"Leeds",zip:"LS1 1AA",card:"4242424242424242",exp:"09/28",cvc:"123"});
   placeOrder();`,
  sandbox,
);
const after = vm.runInContext("ORDERS.length", sandbox);
const placed = vm.runInContext("ORDERS[0]", sandbox);
console.log(`${after === before + 1 ? "✅" : "❌"} order placed -> ${placed.num} total ${placed.total} stock decremented`);

vm.runInContext(`location.hash='#/orders/${placed.num}'; route()`, sandbox);
const orderView = bySel.get("#app").innerHTML;
console.log(`${orderView.includes("Thank you, Test") ? "✅" : "❌"} order confirmation renders`);

// Admin sees the new order
vm.runInContext(`ATAB='ord'; route()`, sandbox);
const adminOrders = bySel.get("#app").innerHTML;
console.log(`${adminOrders.includes(placed.num) ? "✅" : "❌"} admin orders list shows the new order`);

// Review submission + rating recalculation
const revBefore = vm.runInContext("DB.reviews.length", sandbox);
vm.runInContext(
  `DB.reviews.unshift({id:99999,slug:"ashen-crown",author:"QA",loc:"",r:1,title:"t",body:"long enough body",verified:false,helpful:0,at:Date.now()}); recalc(); persist();`,
  sandbox,
);
const revAfter = vm.runInContext("DB.reviews.length", sandbox);
const newRating = vm.runInContext('DB.products.find(p=>p.slug==="ashen-crown").rating', sandbox);
console.log(`${revAfter === revBefore + 1 ? "✅" : "❌"} review added; ashen-crown rating recalculated to ${newRating}`);
vm.runInContext("DB.reviews=DB.reviews.filter(r=>r.id!==99999); recalc(); persist();", sandbox);

// Product CRUD through the admin
vm.runInContext(`editProduct(null)`, sandbox);
const modalOpen = vm.runInContext("!!AEDIT", sandbox);
console.log(`${modalOpen ? "✅" : "❌"} product modal opens`);
const countBefore = vm.runInContext("DB.products.length", sandbox);
vm.runInContext(
  `Object.assign(AEDIT,{title:"QA Test Game",price:1234,stock:5,genre:"RPG"}); saveProduct();`,
  sandbox,
);
const countAfter = vm.runInContext("DB.products.length", sandbox);
console.log(`${countAfter === countBefore + 1 ? "✅" : "❌"} product created (${countAfter} total)`);

console.log(`\n${pass}/${routes.length} storefront routes rendered cleanly.`);
