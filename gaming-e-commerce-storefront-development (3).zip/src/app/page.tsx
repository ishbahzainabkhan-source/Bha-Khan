import Link from "next/link";
import { ProductCard } from "@/components/product/product-card";
import { Newsletter } from "@/components/home/newsletter";
import { Reveal } from "@/components/ui/reveal";
import { Stars } from "@/components/ui/stars";
import {
  getCollections,
  getProducts,
  getStorefrontStats,
  getTopReviews,
} from "@/lib/queries";
import { formatPrice } from "@/lib/format";

export const dynamic = "force-dynamic";

const PROMISES = [
  {
    title: "Hand-checked stock",
    body: "Every disc, key and box is verified by a human before it leaves the shop.",
    icon: "M12 2 4 6v6c0 5 3.4 8.9 8 10 4.6-1.1 8-5 8-10V6l-8-4Z",
  },
  {
    title: "Free express over $75",
    body: "Tracked, insured and carbon-offset delivery to 94 countries.",
    icon: "M3 7h11v8H3zM14 10h4l3 3v2h-7zM7 19a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM18 19a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z",
  },
  {
    title: "Price-match promise",
    body: "Find it cheaper within 14 days and we refund the difference, no forms.",
    icon: "M12 2v20M17 6H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6",
  },
  {
    title: "30-day returns",
    body: "Changed your mind? Send it back unopened for a full refund.",
    icon: "M3 12a9 9 0 1 0 3-6.7M3 4v5h5",
  },
];

export default async function HomePage() {
  const [collections, featured, newReleases, deals, reviews, stats] = await Promise.all([
    getCollections(),
    getProducts({ sort: "featured" }),
    getProducts({ sort: "newest" }),
    getProducts({ onSale: true, sort: "price-asc" }),
    getTopReviews(6),
    getStorefrontStats(),
  ]);

  const hero = featured[0];
  const picks = featured.slice(0, 8);
  const fresh = newReleases.filter((p) => p.isNew).slice(0, 4);
  const sale = deals.slice(0, 4);
  const spotlight = featured.find((p) => p.slug === "ashen-crown") ?? featured[1];

  return (
    <>
      {/* ---------------------------------------------------------------- HERO */}
      <section className="relative isolate overflow-hidden">
        <div className="absolute inset-0 -z-10">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="/images/hero.jpg"
            alt=""
            className="size-full object-cover opacity-55"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-void/80 via-void/60 to-void" />
          <div className="absolute inset-0 bg-gradient-to-r from-void via-void/40 to-transparent" />
        </div>

        <div className="mx-auto grid max-w-[1400px] gap-14 px-5 pb-20 pt-16 sm:px-8 sm:pt-24 lg:grid-cols-[1.15fr_0.85fr] lg:items-center lg:pb-28">
          <div>
            <Reveal>
              <span className="inline-flex items-center gap-2 rounded-full border border-gold/30 bg-gold/10 px-4 py-1.5 text-[11px] tracking-[0.22em] text-gold-soft uppercase">
                <span className="size-1.5 animate-pulse rounded-full bg-gold" />
                Est. 2011 · Independent game merchants
              </span>
            </Reveal>

            <Reveal delay={90}>
              <h1 className="mt-7 font-display text-[clamp(3rem,8vw,6.5rem)] leading-[0.92] tracking-tight">
                Games worth
                <br />
                <span className="gold-text italic">keeping on</span>
                <br />
                the shelf.
              </h1>
            </Reveal>

            <Reveal delay={180}>
              <p className="mt-7 max-w-xl text-base leading-relaxed text-mist sm:text-lg">
                Bha Khan is a small shop with strong opinions. {stats.total} hand-picked titles across
                PC and console — each one played, written up and priced honestly by people who
                finish the credits.
              </p>
            </Reveal>

            <Reveal delay={260}>
              <div className="mt-9 flex flex-col gap-3 sm:flex-row sm:items-center">
                <Link
                  href="/shop"
                  className="group inline-flex items-center justify-center gap-2 rounded-full bg-bone px-8 py-4 text-sm font-bold tracking-wide text-void transition hover:bg-gold-soft"
                >
                  Browse the shop
                  <svg
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    className="transition-transform group-hover:translate-x-1"
                  >
                    <path d="M5 12h14M13 6l6 6-6 6" />
                  </svg>
                </Link>
                <Link
                  href="/collections"
                  className="inline-flex items-center justify-center rounded-full border border-edge bg-void/40 px-8 py-4 text-sm font-semibold text-bone backdrop-blur transition hover:border-gold/50"
                >
                  Explore collections
                </Link>
              </div>
            </Reveal>

            <Reveal delay={340}>
              <dl className="mt-12 grid max-w-xl grid-cols-3 gap-6 border-t border-edge pt-8">
                {[
                  { label: "Titles in stock", value: `${stats.total}` },
                  { label: "Verified reviews", value: `${stats.ratings}` },
                  { label: "Copies shipped", value: `${(stats.sold / 1000).toFixed(1)}k` },
                ].map((item) => (
                  <div key={item.label}>
                    <dt className="text-[11px] tracking-[0.18em] text-mist uppercase">
                      {item.label}
                    </dt>
                    <dd className="mt-1.5 font-display text-3xl">{item.value}</dd>
                  </div>
                ))}
              </dl>
            </Reveal>
          </div>

          {hero ? (
            <Reveal delay={220}>
              <Link
                href={`/product/${hero.slug}`}
                className="group relative block overflow-hidden rounded-3xl border border-edge bg-panel/60 p-3 backdrop-blur-xl"
              >
                <div className="relative aspect-[3/4] overflow-hidden rounded-2xl">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={hero.coverImage}
                    alt={hero.title}
                    className="size-full object-cover transition-transform duration-[1200ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-void via-void/10 to-transparent" />
                  <span className="absolute left-4 top-4 rounded-full bg-bone px-3 py-1 text-[10px] font-bold tracking-[0.18em] text-void uppercase">
                    Shop pick of the month
                  </span>
                  <div className="absolute inset-x-4 bottom-4">
                    <p className="text-[11px] tracking-[0.2em] text-gold-soft uppercase">
                      {hero.genre} · {hero.platform}
                    </p>
                    <h2 className="mt-1.5 font-display text-3xl leading-tight">{hero.title}</h2>
                    <p className="mt-1 line-clamp-2 text-xs text-mist">{hero.tagline}</p>
                    <div className="mt-4 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Stars value={hero.ratingAvg} size={14} />
                        <span className="text-[11px] text-mist">{hero.ratingCount} reviews</span>
                      </div>
                      <span className="font-display text-2xl">{formatPrice(hero.price)}</span>
                    </div>
                  </div>
                </div>
              </Link>
            </Reveal>
          ) : null}
        </div>
      </section>

      {/* -------------------------------------------------------- COLLECTIONS */}
      <section className="mx-auto max-w-[1400px] px-5 py-20 sm:px-8">
        <Reveal className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="eyebrow text-gold">Curated shelves</p>
            <h2 className="mt-3 font-display text-4xl sm:text-5xl">Featured collections</h2>
          </div>
          <Link
            href="/collections"
            className="group inline-flex items-center gap-2 text-sm text-mist transition hover:text-bone"
          >
            See all six
            <svg
              width="15"
              height="15"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              className="transition-transform group-hover:translate-x-1"
            >
              <path d="M5 12h14M13 6l6 6-6 6" />
            </svg>
          </Link>
        </Reveal>

        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {collections.map((collection, index) => (
            <Reveal key={collection.slug} delay={index * 70}>
              <Link
                href={`/collections/${collection.slug}`}
                className="group relative block h-72 overflow-hidden rounded-2xl border border-edge"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={collection.image}
                  alt={collection.name}
                  loading="lazy"
                  className="absolute inset-0 size-full object-cover transition-transform duration-[1100ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-110"
                />
                <div
                  className="absolute inset-0 opacity-70 mix-blend-multiply transition-opacity duration-500 group-hover:opacity-50"
                  style={{
                    backgroundImage: `linear-gradient(150deg, ${collection.accentFrom}, ${collection.accentTo})`,
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-void via-void/35 to-transparent" />
                <div className="absolute inset-x-5 bottom-5">
                  <h3 className="font-display text-3xl leading-tight">{collection.name}</h3>
                  <p className="mt-1 text-xs text-bone/70">{collection.tagline}</p>
                  <span className="mt-4 inline-flex items-center gap-1.5 text-[11px] tracking-[0.2em] text-gold-soft uppercase">
                    Shop collection
                    <svg
                      width="13"
                      height="13"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.4"
                      className="transition-transform group-hover:translate-x-1"
                    >
                      <path d="M5 12h14M13 6l6 6-6 6" />
                    </svg>
                  </span>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ------------------------------------------------------ CURATOR PICKS */}
      <section className="border-y border-edge bg-ink/60 py-20">
        <div className="mx-auto max-w-[1400px] px-5 sm:px-8">
          <Reveal className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="eyebrow text-gold">Signed off by the counter</p>
              <h2 className="mt-3 font-display text-4xl sm:text-5xl">Curator&apos;s picks</h2>
              <p className="mt-3 max-w-lg text-sm text-mist">
                The eight titles we put in people&apos;s hands when they ask &ldquo;what should I
                actually play?&rdquo;
              </p>
            </div>
            <Link
              href="/shop?sort=featured"
              className="rounded-full border border-edge px-5 py-2.5 text-sm text-mist transition hover:border-gold/50 hover:text-bone"
            >
              View all {stats.total} titles
            </Link>
          </Reveal>

          <div className="mt-10 grid grid-cols-2 gap-5 lg:grid-cols-4">
            {picks.map((product, index) => (
              <Reveal key={product.slug} delay={(index % 4) * 70}>
                <ProductCard product={product} priority={index < 4} />
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ----------------------------------------------------------- SPOTLIGHT */}
      {spotlight ? (
        <section className="relative isolate overflow-hidden py-24">
          <div className="absolute inset-0 -z-10">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={spotlight.gallery[1] ?? spotlight.coverImage}
              alt=""
              loading="lazy"
              className="size-full object-cover opacity-25"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-void via-void/85 to-void/50" />
          </div>

          <div className="mx-auto grid max-w-[1400px] items-center gap-12 px-5 sm:px-8 lg:grid-cols-[0.85fr_1.15fr]">
            <Reveal>
              <div className="relative mx-auto w-full max-w-sm">
                <div className="absolute -inset-4 rounded-[28px] bg-gradient-to-br from-gold/25 to-transparent blur-2xl" />
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={spotlight.coverImage}
                  alt={spotlight.title}
                  loading="lazy"
                  className="relative aspect-[3/4] w-full rounded-2xl border border-edge object-cover shadow-[0_40px_90px_-30px_rgba(0,0,0,0.9)]"
                />
              </div>
            </Reveal>

            <Reveal delay={120}>
              <p className="eyebrow text-gold">Staff spotlight</p>
              <h2 className="mt-4 font-display text-[clamp(2.5rem,5vw,4.5rem)] leading-[0.95]">
                {spotlight.title}
              </h2>
              <p className="mt-4 font-display text-xl text-gold-soft italic">{spotlight.tagline}</p>
              <p className="mt-5 max-w-2xl text-sm leading-relaxed text-mist sm:text-base">
                {spotlight.description}
              </p>
              <ul className="mt-7 grid gap-3 sm:grid-cols-2">
                {spotlight.highlights.slice(0, 4).map((highlight) => (
                  <li key={highlight} className="flex gap-2.5 text-sm text-bone/80">
                    <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-gold" />
                    {highlight}
                  </li>
                ))}
              </ul>
              <div className="mt-9 flex flex-wrap items-center gap-4">
                <Link
                  href={`/product/${spotlight.slug}`}
                  className="rounded-full bg-bone px-8 py-3.5 text-sm font-bold text-void transition hover:bg-gold-soft"
                >
                  View {formatPrice(spotlight.price)}
                </Link>
                <div className="flex items-center gap-2">
                  <Stars value={spotlight.ratingAvg} size={16} />
                  <span className="text-sm text-mist">
                    {spotlight.ratingAvg.toFixed(1)} from {spotlight.ratingCount} reviews
                  </span>
                </div>
              </div>
            </Reveal>
          </div>
        </section>
      ) : null}

      {/* ------------------------------------------------------ NEW + ON SALE */}
      <section className="mx-auto max-w-[1400px] space-y-20 px-5 py-10 sm:px-8">
        <div>
          <Reveal className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="eyebrow text-gold">Hot off the press</p>
              <h2 className="mt-3 font-display text-4xl sm:text-5xl">Just landed</h2>
            </div>
            <Link
              href="/shop?sort=newest"
              className="text-sm text-mist transition hover:text-bone"
            >
              All new releases →
            </Link>
          </Reveal>
          <div className="mt-8 grid grid-cols-2 gap-5 lg:grid-cols-4">
            {fresh.map((product, index) => (
              <Reveal key={product.slug} delay={(index % 4) * 70}>
                <ProductCard product={product} />
              </Reveal>
            ))}
          </div>
        </div>

        <div>
          <Reveal className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="eyebrow text-rose-400">Clearance shelf</p>
              <h2 className="mt-3 font-display text-4xl sm:text-5xl">This week&apos;s deals</h2>
            </div>
            <Link href="/shop?onSale=1" className="text-sm text-mist transition hover:text-bone">
              All reductions →
            </Link>
          </Reveal>
          <div className="mt-8 grid grid-cols-2 gap-5 lg:grid-cols-4">
            {sale.map((product, index) => (
              <Reveal key={product.slug} delay={(index % 4) * 70}>
                <ProductCard product={product} />
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ------------------------------------------------------------ PROMISES */}
      <section className="border-y border-edge bg-ink/60 py-16">
        <div className="mx-auto grid max-w-[1400px] gap-8 px-5 sm:grid-cols-2 sm:px-8 lg:grid-cols-4">
          {PROMISES.map((promise, index) => (
            <Reveal key={promise.title} delay={index * 70}>
              <div className="flex gap-4">
                <span className="grid size-11 shrink-0 place-items-center rounded-xl border border-gold/25 bg-gold/10 text-gold">
                  <svg
                    width="19"
                    height="19"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d={promise.icon} />
                  </svg>
                </span>
                <div>
                  <h3 className="font-semibold">{promise.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-mist">{promise.body}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* -------------------------------------------------------- TESTIMONIALS */}
      <section className="mx-auto max-w-[1400px] px-5 py-20 sm:px-8">
        <Reveal>
          <p className="eyebrow text-gold">From the community</p>
          <h2 className="mt-3 max-w-2xl font-display text-4xl sm:text-5xl">
            {stats.ratings} verified reviews, written by people who finished the game.
          </h2>
        </Reveal>

        <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {reviews.map((review, index) => (
            <Reveal key={review.id} delay={(index % 3) * 80}>
              <figure className="flex h-full flex-col rounded-2xl border border-edge bg-panel/40 p-6">
                <Stars value={review.rating} size={14} />
                <figcaption className="mt-4 font-display text-xl">{review.title}</figcaption>
                <blockquote className="mt-2 flex-1 text-sm leading-relaxed text-mist">
                  “{review.body}”
                </blockquote>
                <div className="mt-5 flex items-center gap-3 border-t border-edge pt-4">
                  <span className="grid size-9 place-items-center rounded-full bg-gradient-to-br from-gold/30 to-violet/20 text-xs font-bold text-bone">
                    {review.author
                      .split(" ")
                      .map((part) => part[0])
                      .join("")
                      .slice(0, 2)}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{review.author}</p>
                    <p className="truncate text-[11px] text-mist">
                      {review.location} · on{" "}
                      <Link
                        href={`/product/${review.productSlug}`}
                        className="text-gold-soft hover:underline"
                      >
                        {review.productTitle}
                      </Link>
                    </p>
                  </div>
                </div>
              </figure>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ---------------------------------------------------------- NEWSLETTER */}
      <section className="mx-auto max-w-[1400px] px-5 pb-10 sm:px-8">
        <Reveal>
          <Newsletter />
        </Reveal>
      </section>
    </>
  );
}
