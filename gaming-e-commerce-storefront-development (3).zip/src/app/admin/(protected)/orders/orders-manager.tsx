"use client";

import { useMemo, useState } from "react";
import { cx, formatDate, formatPrice } from "@/lib/format";

export type AdminOrder = {
  id: number;
  orderNumber: string;
  fullName: string;
  email: string;
  address: string;
  city: string;
  postalCode: string;
  country: string;
  deliveryMethod: string;
  promoCode: string | null;
  subtotal: number;
  discount: number;
  shipping: number;
  tax: number;
  total: number;
  status: string;
  items: { slug: string; title: string; edition: string; platform: string; price: number; quantity: number }[];
  createdAt: string;
};

export type AdminReview = {
  id: number;
  productSlug: string;
  productTitle: string | null;
  author: string;
  location: string;
  rating: number;
  title: string;
  body: string;
  verified: boolean;
  helpful: number;
  createdAt: string;
};

const STATUSES = ["confirmed", "packing", "shipped", "delivered", "refunded"];

export function OrdersManager({
  initialOrders,
  initialReviews,
}: {
  initialOrders: AdminOrder[];
  initialReviews: AdminReview[];
}) {
  const [tab, setTab] = useState<"orders" | "reviews">("orders");
  const [orders, setOrders] = useState(initialOrders);
  const [reviews, setReviews] = useState(initialReviews);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all");
  const [open, setOpen] = useState<number | null>(null);
  const [flash, setFlash] = useState("");

  const filteredOrders = useMemo(() => {
    const term = query.trim().toLowerCase();
    return orders.filter((order) => {
      if (filter !== "all" && order.status !== filter) return false;
      if (!term) return true;
      return [order.orderNumber, order.fullName, order.email].join(" ").toLowerCase().includes(term);
    });
  }, [orders, query, filter]);

  const revenue = orders
    .filter((order) => order.status !== "refunded")
    .reduce((sum, order) => sum + order.total, 0);

  const setOrderStatus = async (id: number, status: string) => {
    const response = await fetch("/api/admin/orders", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, status }),
    });
    if (response.ok) {
      setOrders((current) => current.map((o) => (o.id === id ? { ...o, status } : o)));
      setFlash(`Order marked ${status}.`);
    } else {
      setFlash("Could not update that order.");
    }
  };

  const toggleVerified = async (review: AdminReview) => {
    const response = await fetch("/api/admin/reviews", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: review.id, verified: !review.verified }),
    });
    if (response.ok) {
      setReviews((current) =>
        current.map((r) => (r.id === review.id ? { ...r, verified: !r.verified } : r)),
      );
      setFlash(review.verified ? "Review unverified." : "Review marked verified.");
    }
  };

  const deleteReview = async (review: AdminReview) => {
    if (!window.confirm(`Delete the review by ${review.author}?`)) return;
    const response = await fetch(`/api/admin/reviews?id=${review.id}`, { method: "DELETE" });
    if (response.ok) {
      setReviews((current) => current.filter((r) => r.id !== review.id));
      setFlash("Review deleted and product rating recalculated.");
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-2">
        {(
          [
            ["orders", `Orders (${orders.length})`],
            ["reviews", `Reviews (${reviews.length})`],
          ] as const
        ).map(([key, labelText]) => (
          <button
            key={key}
            type="button"
            onClick={() => setTab(key)}
            className={cx(
              "rounded-full border px-5 py-2 text-sm transition",
              tab === key
                ? "border-gold/50 bg-gold/10 text-gold-soft"
                : "border-edge text-mist hover:text-bone",
            )}
          >
            {labelText}
          </button>
        ))}
        <span className="ml-auto text-xs text-mist">
          Booked revenue <span className="text-bone tabular-nums">{formatPrice(revenue)}</span>
        </span>
      </div>

      {flash && (
        <p className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-4 py-2.5 text-xs text-emerald-300">
          {flash}
        </p>
      )}

      {tab === "orders" ? (
        <>
          <div className="flex flex-wrap items-center gap-2">
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search order number, name or email…"
              className="w-full max-w-sm rounded-xl border border-edge bg-void/60 px-3.5 py-2.5 text-sm outline-none focus:border-gold/50"
            />
            <select
              value={filter}
              onChange={(event) => setFilter(event.target.value)}
              className="rounded-xl border border-edge bg-void/60 px-3.5 py-2.5 text-sm outline-none focus:border-gold/50"
            >
              <option value="all" className="bg-ink">All statuses</option>
              {STATUSES.map((status) => (
                <option key={status} value={status} className="bg-ink">
                  {status}
                </option>
              ))}
            </select>
            <span className="text-xs text-mist tabular-nums">{filteredOrders.length} shown</span>
          </div>

          {filteredOrders.length === 0 ? (
            <p className="rounded-2xl border border-dashed border-edge px-6 py-16 text-center text-sm text-mist">
              No orders match. Place a test order from the storefront to see the pipeline working.
            </p>
          ) : (
            <ul className="space-y-3">
              {filteredOrders.map((order) => (
                <li key={order.id} className="rounded-2xl border border-edge bg-panel/30">
                  <button
                    type="button"
                    onClick={() => setOpen(open === order.id ? null : order.id)}
                    className="flex w-full flex-wrap items-center gap-4 px-5 py-4 text-left"
                  >
                    <span className="font-mono text-xs text-gold-soft">{order.orderNumber}</span>
                    <span className="min-w-0 flex-1 truncate text-sm">
                      {order.fullName}
                      <span className="text-mist"> · {order.email}</span>
                    </span>
                    <span className="text-[11px] text-mist">{formatDate(order.createdAt)}</span>
                    <span
                      className={cx(
                        "rounded-full px-2.5 py-1 text-[10px] tracking-wide uppercase",
                        order.status === "refunded"
                          ? "bg-rose-500/15 text-rose-300"
                          : order.status === "delivered"
                            ? "bg-emerald-500/15 text-emerald-300"
                            : "bg-edge text-mist",
                      )}
                    >
                      {order.status}
                    </span>
                    <span className="text-sm tabular-nums">{formatPrice(order.total)}</span>
                  </button>

                  {open === order.id && (
                    <div className="border-t border-edge px-5 py-5">
                      <div className="grid gap-4 sm:grid-cols-3">
                        <div>
                          <p className={cx("text-[10px] tracking-[0.16em] text-mist uppercase")}>Delivery</p>
                          <p className="mt-1.5 text-sm capitalize">{order.deliveryMethod}</p>
                          {order.deliveryMethod === "express" && (
                            <p className="mt-1 text-[11px] text-mist">
                              {order.address}, {order.city} {order.postalCode}, {order.country}
                            </p>
                          )}
                        </div>
                        <div>
                          <p className="text-[10px] tracking-[0.16em] text-mist uppercase">Promo</p>
                          <p className="mt-1.5 text-sm">{order.promoCode ?? "—"}</p>
                        </div>
                        <div>
                          <p className="text-[10px] tracking-[0.16em] text-mist uppercase">Set status</p>
                          <select
                            value={order.status}
                            onChange={(event) => setOrderStatus(order.id, event.target.value)}
                            className="mt-1.5 w-full rounded-lg border border-edge bg-void/60 px-3 py-2 text-xs outline-none focus:border-gold/50"
                          >
                            {STATUSES.map((status) => (
                              <option key={status} value={status} className="bg-ink">
                                {status}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <ul className="mt-5 divide-y divide-edge rounded-xl border border-edge">
                        {order.items.map((item) => (
                          <li key={item.slug} className="flex items-center gap-3 px-4 py-3 text-sm">
                            <span className="min-w-0 flex-1 truncate">{item.title}</span>
                            <span className="text-[11px] text-mist">
                              {item.edition} · {item.platform}
                            </span>
                            <span className="text-[11px] text-mist">×{item.quantity}</span>
                            <span className="tabular-nums">
                              {formatPrice(item.price * item.quantity)}
                            </span>
                          </li>
                        ))}
                      </ul>

                      <dl className="mt-4 grid gap-2 text-xs sm:grid-cols-4">
                        <div className="flex justify-between sm:block">
                          <dt className="text-mist">Subtotal</dt>
                          <dd className="tabular-nums">{formatPrice(order.subtotal)}</dd>
                        </div>
                        <div className="flex justify-between sm:block">
                          <dt className="text-mist">Discount</dt>
                          <dd className="tabular-nums">−{formatPrice(order.discount)}</dd>
                        </div>
                        <div className="flex justify-between sm:block">
                          <dt className="text-mist">Shipping</dt>
                          <dd className="tabular-nums">{formatPrice(order.shipping)}</dd>
                        </div>
                        <div className="flex justify-between sm:block">
                          <dt className="text-mist">Tax</dt>
                          <dd className="tabular-nums">{formatPrice(order.tax)}</dd>
                        </div>
                      </dl>
                    </div>
                  )}
                </li>
              ))}
            </ul>
          )}
        </>
      ) : (
        <ul className="space-y-3">
          {reviews.map((review) => (
            <li key={review.id} className="rounded-2xl border border-edge bg-panel/30 p-5">
              <div className="flex flex-wrap items-center gap-3">
                <span className="rounded-full border border-edge px-2.5 py-1 text-[10px] text-gold-soft">
                  {review.rating}★
                </span>
                <span className="min-w-0 flex-1 truncate text-sm">
                  <span className="font-medium">{review.title}</span>
                  <span className="text-mist"> · {review.productTitle ?? review.productSlug}</span>
                </span>
                <span className="text-[11px] text-mist">{formatDate(review.createdAt)}</span>
                <span
                  className={cx(
                    "rounded-full px-2.5 py-1 text-[10px] uppercase",
                    review.verified
                      ? "bg-emerald-500/15 text-emerald-300"
                      : "bg-amber-500/15 text-amber-300",
                  )}
                >
                  {review.verified ? "verified" : "pending"}
                </span>
              </div>
              <p className="mt-3 text-sm leading-relaxed text-mist">{review.body}</p>
              <div className="mt-4 flex flex-wrap items-center gap-3 border-t border-edge pt-3">
                <span className="text-[11px] text-mist">
                  {review.author}
                  {review.location ? ` · ${review.location}` : ""} · {review.helpful} helpful
                </span>
                <button
                  type="button"
                  onClick={() => toggleVerified(review)}
                  className="ml-auto rounded-full border border-edge px-3 py-1.5 text-[11px] transition hover:border-gold/50 hover:text-gold-soft"
                >
                  {review.verified ? "Unverify" : "Verify"}
                </button>
                <a
                  href={`/product/${review.productSlug}`}
                  target="_blank"
                  rel="noreferrer"
                  className="rounded-full border border-edge px-3 py-1.5 text-[11px] text-mist transition hover:text-bone"
                >
                  View product
                </a>
                <button
                  type="button"
                  onClick={() => deleteReview(review)}
                  className="rounded-full border border-rose-500/30 px-3 py-1.5 text-[11px] text-rose-300 transition hover:bg-rose-500/10"
                >
                  Delete
                </button>
              </div>
            </li>
          ))}
          {reviews.length === 0 && (
            <li className="rounded-2xl border border-dashed border-edge px-6 py-16 text-center text-sm text-mist">
              No reviews to moderate.
            </li>
          )}
        </ul>
      )}
    </div>
  );
}
