import { NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { reviews } from "@/db/schema";
import { isAdmin } from "@/lib/admin";
import { refreshProductRating } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  }
  const rows = await db.select().from(reviews);
  return NextResponse.json({ reviews: rows });
}

export async function PATCH(request: Request) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  }
  const body = (await request.json().catch(() => ({}))) as {
    id?: number;
    verified?: boolean;
    helpful?: number;
  };
  const id = Number(body.id);
  if (!id) return NextResponse.json({ error: "Missing review id." }, { status: 400 });

  const patch: Record<string, unknown> = {};
  if (typeof body.verified === "boolean") patch.verified = body.verified;
  if (typeof body.helpful === "number") patch.helpful = Math.max(0, Math.round(body.helpful));
  if (!Object.keys(patch).length) {
    return NextResponse.json({ error: "Nothing to update." }, { status: 400 });
  }

  const [updated] = await db.update(reviews).set(patch).where(eq(reviews.id, id)).returning();
  if (!updated) return NextResponse.json({ error: "Review not found." }, { status: 404 });

  await refreshProductRating(updated.productSlug);
  revalidatePath(`/product/${updated.productSlug}`);
  return NextResponse.json({ review: updated });
}

export async function DELETE(request: Request) {
  if (!(await isAdmin())) {
    return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  }
  const id = Number(new URL(request.url).searchParams.get("id"));
  if (!id) return NextResponse.json({ error: "Missing review id." }, { status: 400 });

  const [removed] = await db.delete(reviews).where(eq(reviews.id, id)).returning();
  if (!removed) return NextResponse.json({ error: "Review not found." }, { status: 404 });

  await refreshProductRating(removed.productSlug);
  revalidatePath(`/product/${removed.productSlug}`);
  return NextResponse.json({ ok: true });
}
