import { db } from "@/db";
import { orders, type OrderLine } from "@/db/schema";
import { getProductsBySlugs } from "@/lib/queries";
import { priceOrder } from "@/lib/promos";

export const dynamic = "force-dynamic";

const EDITION_DELTA: Record<string, number> = {
  "": 0,
  deluxe: 1500,
  collector: 4500,
};

function orderNumber() {
  const letters = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 6; i += 1) {
    code += letters[Math.floor(Math.random() * letters.length)];
  }
  return `BK-${code}`;
}

export async function POST(request: Request) {
  try {
    const payload = (await request.json()) as {
      items?: { slug: string; quantity: number }[];
      email?: string;
      fullName?: string;
      address?: string;
      city?: string;
      postalCode?: string;
      country?: string;
      deliveryMethod?: string;
      promoCode?: string;
    };

    const rawItems = (payload.items ?? []).filter(
      (item) => item && typeof item.slug === "string" && Number(item.quantity) > 0,
    );
    if (!rawItems.length) {
      return Response.json({ error: "Your bag is empty." }, { status: 400 });
    }

    const email = (payload.email ?? "").trim();
    const fullName = (payload.fullName ?? "").trim();
    if (!email.includes("@") || fullName.length < 2) {
      return Response.json({ error: "Please provide a valid name and email." }, { status: 400 });
    }

    const baseSlugs = [...new Set(rawItems.map((item) => item.slug.split("--")[0]))];
    const products = await getProductsBySlugs(baseSlugs);
    const bySlug = new Map(products.map((product) => [product.slug, product]));

    const lines: OrderLine[] = [];
    for (const item of rawItems) {
      const [baseSlug, editionKey = ""] = item.slug.split("--");
      const product = bySlug.get(baseSlug);
      if (!product) continue;
      const delta = EDITION_DELTA[editionKey] ?? 0;
      const quantity = Math.max(1, Math.min(10, Math.round(Number(item.quantity))));
      lines.push({
        slug: item.slug,
        title: product.title,
        edition: editionKey
          ? `${editionKey[0].toUpperCase()}${editionKey.slice(1)} Edition`
          : product.edition,
        platform: product.platform,
        price: product.price + delta,
        quantity,
        coverImage: product.coverImage,
      });
    }

    if (!lines.length) {
      return Response.json({ error: "None of those titles are available." }, { status: 400 });
    }

    const subtotal = lines.reduce((sum, line) => sum + line.price * line.quantity, 0);
    const deliveryMethod = payload.deliveryMethod === "digital" ? "digital" : "express";
    const code = (payload.promoCode ?? "").trim().toUpperCase();
    const { promo, discount, shipping, tax, total } = priceOrder({
      subtotal,
      promoCode: code,
      deliveryMethod,
    });

    let number = orderNumber();
    for (let attempt = 0; attempt < 4; attempt += 1) {
      try {
        const [created] = await db
          .insert(orders)
          .values({
            orderNumber: number,
            email,
            fullName,
            address: (payload.address ?? "").trim(),
            city: (payload.city ?? "").trim(),
            postalCode: (payload.postalCode ?? "").trim(),
            country: (payload.country ?? "").trim(),
            deliveryMethod,
            promoCode: promo ? code : null,
            subtotal,
            discount,
            shipping,
            tax,
            total,
            items: lines,
            status: "confirmed",
          })
          .returning();
        return Response.json({ orderNumber: created.orderNumber });
      } catch {
        number = orderNumber();
      }
    }

    return Response.json({ error: "Could not place the order." }, { status: 500 });
  } catch {
    return Response.json({ error: "Could not place the order." }, { status: 500 });
  }
}
