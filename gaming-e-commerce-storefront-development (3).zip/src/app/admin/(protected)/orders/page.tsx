import { getAdminOrders, getAdminReviews } from "@/lib/admin";
import { OrdersManager } from "./orders-manager";

export const dynamic = "force-dynamic";

export default async function AdminOrdersPage() {
  const [orderRows, reviewRows] = await Promise.all([getAdminOrders(), getAdminReviews()]);

  const orders = orderRows.map((order) => ({
    id: order.id,
    orderNumber: order.orderNumber,
    fullName: order.fullName,
    email: order.email,
    address: order.address,
    city: order.city,
    postalCode: order.postalCode,
    country: order.country,
    deliveryMethod: order.deliveryMethod,
    promoCode: order.promoCode,
    subtotal: order.subtotal,
    discount: order.discount,
    shipping: order.shipping,
    tax: order.tax,
    total: order.total,
    status: order.status,
    items: order.items,
    createdAt: order.createdAt.toISOString(),
  }));

  const reviews = reviewRows.map((review) => ({
    id: review.id,
    productSlug: review.productSlug,
    productTitle: review.productTitle,
    author: review.author,
    location: review.location,
    rating: review.rating,
    title: review.title,
    body: review.body,
    verified: review.verified,
    helpful: review.helpful,
    createdAt: review.createdAt.toISOString(),
  }));

  return <OrdersManager initialOrders={orders} initialReviews={reviews} />;
}
