"use client";

import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import Link from "next/link";

export default function AdminLoginPage() {
  const router = useRouter();
  const [passcode, setPasscode] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/admin/session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ passcode }),
      });
      if (!response.ok) {
        const data = (await response.json()) as { error?: string };
        throw new Error(data.error ?? "Sign-in failed.");
      }
      router.replace("/admin");
      router.refresh();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Sign-in failed.");
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto flex min-h-[70vh] max-w-md flex-col justify-center px-5 py-20">
      <div className="rounded-3xl border border-edge bg-panel/40 p-8">
        <span className="grid size-12 place-items-center rounded-2xl bg-gradient-to-br from-gold-soft via-gold to-[#8a6425] text-void">
          <span className="font-display text-2xl leading-none">B</span>
        </span>
        <h1 className="mt-6 font-display text-4xl">Back office</h1>
        <p className="mt-2 text-sm text-mist">
          Sign in to manage stock, pricing, orders and reviews.
        </p>

        <form onSubmit={submit} className="mt-7 space-y-4">
          <label className="block">
            <span className="eyebrow block text-mist">Passcode</span>
            <input
              type="password"
              value={passcode}
              onChange={(event) => setPasscode(event.target.value)}
              placeholder="••••••••"
              autoFocus
              className="mt-2 w-full rounded-xl border border-edge bg-void/60 px-4 py-3 text-sm outline-none transition focus:border-gold/50"
            />
          </label>
          {error && (
            <p className="rounded-xl border border-rose-500/40 bg-rose-500/10 px-4 py-2.5 text-xs text-rose-300">
              {error}
            </p>
          )}
          <button
            type="submit"
            disabled={busy}
            className="w-full rounded-full bg-gradient-to-r from-gold-soft via-gold to-gold-soft bg-[length:200%_100%] px-6 py-3.5 text-sm font-bold text-void transition-[background-position] duration-700 hover:bg-right disabled:opacity-60"
          >
            {busy ? "Checking…" : "Enter the back office"}
          </button>
        </form>

        <p className="mt-5 rounded-xl border border-edge bg-void/40 px-4 py-3 text-[11px] leading-relaxed text-mist">
          Demo passcode: <span className="text-gold-soft">khan2026</span> — override it in
          production by setting the <code className="text-bone">ADMIN_PASSCODE</code> environment
          variable.
        </p>
      </div>

      <Link href="/" className="mt-6 text-center text-xs text-mist transition hover:text-bone">
        ← Back to the storefront
      </Link>
    </div>
  );
}
