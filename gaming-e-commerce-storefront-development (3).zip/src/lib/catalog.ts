export type SortKey =
  | "featured"
  | "price-asc"
  | "price-desc"
  | "rating"
  | "newest"
  | "bestselling";

export const SORT_OPTIONS: { value: SortKey; label: string }[] = [
  { value: "featured", label: "Curator's picks" },
  { value: "bestselling", label: "Best selling" },
  { value: "rating", label: "Top rated" },
  { value: "newest", label: "Newest releases" },
  { value: "price-asc", label: "Price: low to high" },
  { value: "price-desc", label: "Price: high to low" },
];
