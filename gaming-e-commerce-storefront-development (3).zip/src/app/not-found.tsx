import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto flex min-h-[60vh] max-w-2xl flex-col items-center justify-center px-5 py-24 text-center">
      <p className="eyebrow text-gold">Error 404</p>
      <h1 className="mt-5 font-display text-[clamp(3rem,10vw,6rem)] leading-[0.9]">
        This shelf is empty
      </h1>
      <p className="mt-5 max-w-md text-sm leading-relaxed text-mist">
        We couldn&apos;t find that page. It may have sold out, moved shelves, or never existed —
        the counter team is looking into it.
      </p>
      <div className="mt-9 flex flex-col gap-3 sm:flex-row">
        <Link
          href="/shop"
          className="rounded-full bg-bone px-8 py-3.5 text-sm font-bold text-void transition hover:bg-gold-soft"
        >
          Browse the shop
        </Link>
        <Link
          href="/"
          className="rounded-full border border-edge px-8 py-3.5 text-sm font-semibold transition hover:border-gold/50"
        >
          Back home
        </Link>
      </div>
    </div>
  );
}
