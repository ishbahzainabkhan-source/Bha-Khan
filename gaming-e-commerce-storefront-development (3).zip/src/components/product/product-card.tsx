"use client";

import Link from "next/link";
import type { Product } from "@/db/schema";
import { useCart } from "@/components/cart/cart-provider";
import { Stars } from "@/components/ui/stars";
import { cx, discountPercent, formatPrice } from "@/lib/format";

export function ProductCard({
  product,
  priority = false,
  compact = false,
}: {
  product: Product;
  priority?: boolean;
  compact?: boolean;
}) {
  const { addItem } = useCart();
  const off = discountPercent(product.price, product.compareAtPrice);
  const soldOut = product.stock <= 0;

  return (
    <article className="group card-hover relative flex h-full flex-col overflow-hidden rounded-2xl border border-edge bg-panel/50">
      <Link href={`/product/${product.slug}`} className="relative block overflow-hidden">
        <div className={cx("relative w-full overflow-hidden", compact ? "aspect-[4/3]" : "aspect-[3/4]")}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={product.coverImage}
            alt={product.title}
            loading={priority ? "eager" : "lazy"}
            className="size-full object-cover transition-transform duration-[900ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.07]"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-void via-void/20 to-transparent opacity-80" />
        </div>

        <div className="absolute left-3 top-3 flex flex-col items-start gap-1.5">
          {product.isNew && (
            <span className="rounded-full bg-bone px-2.5 py-1 text-[10px] font-bold tracking-[0.14em] text-void uppercase">
              New
            </span>
          )}
          {off > 0 && (
            <span className="rounded-full bg-rose-500 px-2.5 py-1 text-[10px] font-bold tracking-[0.14em] text-white uppercase">
              −{off}%
            </span>
          )}
          {product.stock > 0 && product.stock <= 10 && (
            <span className="rounded-full bg-amber-500/90 px-2.5 py-1 text-[10px] font-bold tracking-[0.1em] text-void uppercase">
              {product.stock} left
            </span>
          )}
        </div>

        <span className="absolute right-3 top-3 rounded-full border border-white/15 bg-black/50 px-2.5 py-1 text-[10px] tracking-[0.12em] text-bone/90 uppercase backdrop-blur">
          {product.platform}
        </span>
      </Link>

      <div className="relative flex flex-1 flex-col gap-2 p-4">
        <div className="flex items-center gap-2 text-[11px] text-mist">
          <span className="tracking-[0.16em] uppercase">{product.genre}</span>
          <span className="size-1 rounded-full bg-edge" />
          <span>{product.releaseYear}</span>
        </div>

        <Link href={`/product/${product.slug}`}>
          <h3 className="font-display text-xl leading-tight transition-colors group-hover:text-gold-soft">
            {product.title}
          </h3>
        </Link>

        <p className="line-clamp-2 text-xs leading-relaxed text-mist">{product.tagline}</p>

        <div className="mt-1 flex items-center gap-2">
          <Stars value={product.ratingAvg} size={13} />
          <span className="text-[11px] text-mist tabular-nums">
            {product.ratingAvg.toFixed(1)} ({product.ratingCount})
          </span>
        </div>

        <div className="mt-auto flex items-end justify-between gap-3 pt-3">
          <div>
            <p className="font-display text-2xl leading-none tabular-nums">
              {formatPrice(product.price)}
            </p>
            {product.compareAtPrice ? (
              <p className="mt-1 text-xs text-mist line-through tabular-nums">
                {formatPrice(product.compareAtPrice)}
              </p>
            ) : null}
          </div>

          <button
            type="button"
            disabled={soldOut}
            onClick={() =>
              addItem({
                slug: product.slug,
                title: product.title,
                price: product.price,
                compareAtPrice: product.compareAtPrice,
                coverImage: product.coverImage,
                platform: product.platform,
                edition: product.edition,
                stock: product.stock,
              })
            }
            className="flex items-center gap-1.5 rounded-full border border-gold/35 bg-gold/10 px-3.5 py-2 text-xs font-semibold text-gold-soft transition hover:bg-gold hover:text-void disabled:cursor-not-allowed disabled:border-edge disabled:bg-transparent disabled:text-mist"
          >
            {soldOut ? (
              "Sold out"
            ) : (
              <>
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
                  <path d="M12 5v14M5 12h14" />
                </svg>
                Add
              </>
            )}
          </button>
        </div>
      </div>
    </article>
  );
}
