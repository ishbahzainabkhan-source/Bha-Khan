"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState, type FormEvent } from "react";
import { useCart } from "./cart/cart-provider";
import { cx } from "@/lib/format";

const NAV = [
  { href: "/shop", label: "Shop all" },
  { href: "/collections", label: "Collections" },
  { href: "/shop?sort=newest", label: "New releases" },
  { href: "/shop?onSale=1", label: "Deals" },
];

const MARQUEE = [
  "Free express delivery over $75",
  "Price-match promise on every new release",
  "Pre-owned titles verified by hand",
  "30-day no-quibble returns",
  "Loyalty points on every order",
];

export function SiteHeader() {
  const { count, openCart, hydrated } = useCart();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [term, setTerm] = useState("");
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
    setSearchOpen(false);
  }, [pathname]);

  const submitSearch = (event: FormEvent) => {
    event.preventDefault();
    const q = term.trim();
    router.push(q ? `/shop?q=${encodeURIComponent(q)}` : "/shop");
    setSearchOpen(false);
  };

  return (
    <>
      <div className="relative z-[70] overflow-hidden border-b border-edge/70 bg-ink">
        <div className="flex w-max animate-[marquee_38s_linear_infinite] gap-10 py-2 text-[11px] tracking-[0.2em] text-mist uppercase">
          {[...MARQUEE, ...MARQUEE].map((item, index) => (
            <span key={index} className="flex items-center gap-10 whitespace-nowrap">
              <span className="size-1 rounded-full bg-gold/70" />
              {item}
            </span>
          ))}
        </div>
      </div>

      <header
        className={cx(
          "sticky top-0 z-[80] transition-all duration-500",
          scrolled
            ? "border-b border-edge bg-void/85 backdrop-blur-xl"
            : "border-b border-transparent bg-transparent",
        )}
      >
        <div className="mx-auto flex h-18 max-w-[1400px] items-center gap-6 px-5 py-4 sm:px-8">
          <button
            type="button"
            onClick={() => setMenuOpen((v) => !v)}
            className="grid size-9 place-items-center rounded-full border border-edge text-mist transition hover:text-bone lg:hidden"
            aria-label="Toggle menu"
            aria-expanded={menuOpen}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              {menuOpen ? <path d="M18 6 6 18M6 6l12 12" /> : <path d="M3 6h18M3 12h18M3 18h18" />}
            </svg>
          </button>

          <Link href="/" className="group flex items-center gap-3">
            <span className="relative grid size-9 place-items-center rounded-xl bg-gradient-to-br from-gold-soft via-gold to-[#8a6425] text-void shadow-[0_0_24px_rgba(217,178,106,0.28)]">
              <span className="font-display text-lg leading-none">B</span>
            </span>
            <span className="leading-none">
              <span className="block font-display text-xl tracking-tight">
                Bha <span className="gold-text">Khan</span>
              </span>
              <span className="mt-0.5 block text-[9px] tracking-[0.34em] text-mist uppercase">
                Game Merchants
              </span>
            </span>
          </Link>

          <nav className="ml-6 hidden items-center gap-1 lg:flex">
            {NAV.map((item) => (
              <Link
                key={item.label}
                href={item.href}
                className="rounded-full px-4 py-2 text-sm text-mist transition hover:bg-panel hover:text-bone"
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="ml-auto flex items-center gap-2">
            <form
              onSubmit={submitSearch}
              className={cx(
                "hidden items-center overflow-hidden rounded-full border border-edge bg-panel/60 transition-all duration-500 md:flex",
                searchOpen ? "w-64" : "w-44",
              )}
            >
              <span className="pl-3 text-mist">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="11" cy="11" r="7" />
                  <path d="m20 20-3.5-3.5" />
                </svg>
              </span>
              <input
                value={term}
                onChange={(event) => setTerm(event.target.value)}
                onFocus={() => setSearchOpen(true)}
                onBlur={() => setSearchOpen(false)}
                placeholder="Search titles…"
                className="w-full bg-transparent px-3 py-2 text-sm text-bone outline-none placeholder:text-mist/70"
                aria-label="Search games"
              />
            </form>

            <Link
              href="/shop?sort=bestselling"
              className="hidden rounded-full border border-edge px-4 py-2 text-xs tracking-wide text-mist transition hover:border-gold/50 hover:text-bone xl:block"
            >
              Top 10 this week
            </Link>

            <button
              type="button"
              onClick={openCart}
              className="relative flex items-center gap-2 rounded-full border border-gold/30 bg-gold/10 px-4 py-2 text-sm font-medium text-gold-soft transition hover:bg-gold/20"
              aria-label="Open cart"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path d="M3 5h2l2.4 11.2a2 2 0 0 0 2 1.6h7.5a2 2 0 0 0 2-1.6L20.5 8H6" />
                <circle cx="10" cy="20" r="1.3" />
                <circle cx="17" cy="20" r="1.3" />
              </svg>
              <span className="hidden sm:inline">Bag</span>
              {hydrated && count > 0 && (
                <span className="grid min-w-5 place-items-center rounded-full bg-gold px-1.5 text-[11px] font-bold text-void tabular-nums">
                  {count}
                </span>
              )}
            </button>
          </div>
        </div>

        <div
          className={cx(
            "overflow-hidden border-edge bg-ink transition-[max-height,opacity] duration-500 lg:hidden",
            menuOpen ? "max-h-96 border-t opacity-100" : "max-h-0 opacity-0",
          )}
        >
          <nav className="flex flex-col px-5 py-4">
            {NAV.map((item) => (
              <Link
                key={item.label}
                href={item.href}
                className="border-b border-edge/60 py-3 font-display text-xl text-bone last:border-0"
              >
                {item.label}
              </Link>
            ))}
            <form onSubmit={submitSearch} className="mt-4 flex items-center rounded-full border border-edge bg-panel/60">
              <span className="pl-3 text-mist">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="11" cy="11" r="7" />
                  <path d="m20 20-3.5-3.5" />
                </svg>
              </span>
              <input
                value={term}
                onChange={(event) => setTerm(event.target.value)}
                placeholder="Search titles…"
                className="w-full bg-transparent px-3 py-2.5 text-sm outline-none placeholder:text-mist/70"
                aria-label="Search games"
              />
            </form>
          </nav>
        </div>
      </header>
    </>
  );
}
