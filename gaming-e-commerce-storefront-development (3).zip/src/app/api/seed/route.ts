import { ensureSeeded, reseed } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureSeeded();
    return Response.json({ ok: true, seeded: true });
  } catch (error) {
    return Response.json(
      { ok: false, error: error instanceof Error ? error.message : "seed failed" },
      { status: 500 },
    );
  }
}

export async function POST() {
  try {
    await reseed();
    return Response.json({ ok: true, reseeded: true });
  } catch (error) {
    return Response.json(
      { ok: false, error: error instanceof Error ? error.message : "reseed failed" },
      { status: 500 },
    );
  }
}
