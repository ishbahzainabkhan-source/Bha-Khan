import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ProductCard } from "@/components/product/product-card";
import { Reveal } from "@/components/ui/reveal";
import { getCollection, getCollections, getProducts } from "@/lib/queries";
import { formatPrice } from "@/lib/format";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const collection = await getCollection(slug);
  if (!collection) return { title: "Collection not found" };
  return { title: collection.name, description: collection.description };
}

export default async function CollectionPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const collection = await getCollection(slug);
  if (!collection) notFound();

  const [products, allCollections] = await Promise.all([
    getProducts({ collection: slug, sort: "featured" }),
    getCollections(),
  ]);

  const cheapest = products.reduce((min, p) => Math.min(min, p.price), Number.POSITIVE_INFINITY);
  const avgRating =
    products.length > 0
      ? products.reduce((sum, p) => sum + p.ratingAvg, 0) / products.length
      : 0;

  return (
    <div>
      <section className="relative isolate overflow-hidden border-b border-edge">
        <div className="absolute inset-0 -z-10">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={collection.image} alt="" className="size-full object-cover opacity-35" />
          <div
            className="absolute inset-0 opacity-50 mix-blend-multiply"
            style={{
              backgroundImage: `linear-gradient(140deg, ${collection.accentFrom}, ${collection.accentTo})`,
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-void via-void/70 to-void/40" />
        </div>

        <div className="mx-auto max-w-[1400px] px-5 py-20 sm:px-8 sm:py-28">
          <Reveal>
            <nav className="flex items-center gap-2 text-xs text-mist">
              <Link href="/" className="hover:text-bone">
                Home
              </Link>
              <span>/</span>
              <Link href="/collections" className="hover:text-bone">
                Collections
              </Link>
              <span>/</span>
              <span className="text-bone">{collection.name}</span>
            </nav>
            <p className="eyebrow mt-8 text-gold-soft">{collection.tagline}</p>
            <h1 className="mt-4 max-w-4xl font-display text-[clamp(3rem,8vw,6rem)] leading-[0.9]">
              {collection.name}
            </h1>
            <p className="mt-5 max-w-2xl text-sm leading-relaxed text-bone/80 sm:text-base">
              {collection.description}
            </p>
            <dl className="mt-10 flex flex-wrap gap-10 border-t border-white/10 pt-7">
              <div>
                <dt className="text-[11px] tracking-[0.18em] text-mist uppercase">Titles</dt>
                <dd className="mt-1 font-display text-3xl">{products.length}</dd>
              </div>
              <div>
                <dt className="text-[11px] tracking-[0.18em] text-mist uppercase">From</dt>
                <dd className="mt-1 font-display text-3xl">
                  {Number.isFinite(cheapest) ? formatPrice(cheapest) : "—"}
                </dd>
              </div>
              <div>
                <dt className="text-[11px] tracking-[0.18em] text-mist uppercase">Avg. rating</dt>
                <dd className="mt-1 font-display text-3xl">{avgRating.toFixed(1)}</dd>
              </div>
            </dl>
          </Reveal>
        </div>
      </section>

      <div className="mx-auto max-w-[1400px] px-5 py-14 sm:px-8">
        {products.length === 0 ? (
          <p className="rounded-3xl border border-dashed border-edge px-8 py-20 text-center text-sm text-mist">
            This shelf is being restocked — check back soon.
          </p>
        ) : (
          <div className="grid grid-cols-2 gap-5 lg:grid-cols-4">
            {products.map((product, index) => (
              <Reveal key={product.slug} delay={(index % 4) * 70}>
                <ProductCard product={product} priority={index < 4} />
              </Reveal>
            ))}
          </div>
        )}

        <section className="mt-20 border-t border-edge pt-12">
          <p className="eyebrow text-gold">Other shelves</p>
          <div className="mt-6 flex flex-wrap gap-3">
            {allCollections
              .filter((item) => item.slug !== collection.slug)
              .map((item) => (
                <Link
                  key={item.slug}
                  href={`/collections/${item.slug}`}
                  className="group flex items-center gap-3 rounded-2xl border border-edge bg-panel/30 p-3 pr-5 transition hover:border-gold/40"
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={item.image}
                    alt=""
                    loading="lazy"
                    className="size-12 rounded-xl object-cover"
                  />
                  <span>
                    <span className="block font-display text-lg leading-tight">{item.name}</span>
                    <span className="block text-[11px] text-mist">{item.tagline}</span>
                  </span>
                </Link>
              ))}
          </div>
        </section>
      </div>
    </div>
  );
}
