export type Promo = {
  type: "percent" | "fixed" | "shipping";
  value: number;
  label: string;
};

export const PROMOS: Record<string, Promo> = {
  BHAKHAN10: { type: "percent", value: 10, label: "10% welcome discount" },
  PLAYER1: { type: "percent", value: 15, label: "15% loyalty discount" },
  FREESHIP: { type: "shipping", value: 0, label: "Free express delivery" },
  LEVELUP5: { type: "fixed", value: 500, label: "$5 off your order" },
};

export const FREE_SHIPPING_THRESHOLD = 7500;
export const SHIPPING_FLAT = 599;
export const TAX_RATE = 0.08;

export function priceOrder({
  subtotal,
  promoCode,
  deliveryMethod,
}: {
  subtotal: number;
  promoCode?: string;
  deliveryMethod: "digital" | "express";
}) {
  const code = (promoCode ?? "").trim().toUpperCase();
  const promo = code ? PROMOS[code] : undefined;

  let discount = 0;
  let shipping =
    deliveryMethod === "digital" || subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_FLAT;

  if (promo?.type === "percent") discount = Math.round((subtotal * promo.value) / 100);
  if (promo?.type === "fixed") discount = Math.min(promo.value, subtotal);
  if (promo?.type === "shipping") shipping = 0;

  const taxable = Math.max(0, subtotal - discount);
  const tax = Math.round(taxable * TAX_RATE);

  return { promo, discount, shipping, tax, total: taxable + shipping + tax };
}
