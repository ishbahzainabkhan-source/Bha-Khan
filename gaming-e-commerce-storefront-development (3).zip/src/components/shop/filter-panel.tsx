"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useCallback, useEffect, useMemo, useState, useTransition } from "react";
import { cx, formatPrice } from "@/lib/format";
import { SORT_OPTIONS } from "@/lib/catalog";

type Facet = { value: string; count: number };

export type FilterPanelProps = {
  facets: { platforms: Facet[]; genres: Facet[]; maxPrice: number; total: number };
  collections: { slug: string; name: string }[];
  resultCount: number;
};

function parseList(value: string | null) {
  return value ? value.split(",").filter(Boolean) : [];
}

export function FilterPanel({ facets, collections, resultCount }: FilterPanelProps) {
  const router = useRouter();
  const params = useSearchParams();
  const [pending, startTransition] = useTransition();
  const [mobileOpen, setMobileOpen] = useState(false);

  const current = useMemo(
    () => ({
      q: params.get("q") ?? "",
      platforms: parseList(params.get("platform")),
      genres: parseList(params.get("genre")),
      collection: params.get("collection") ?? "",
      max: Number(params.get("max") ?? facets.maxPrice) || facets.maxPrice,
      onSale: params.get("onSale") === "1",
      sort: params.get("sort") ?? "featured",
    }),
    [params, facets.maxPrice],
  );

  const [search, setSearch] = useState(current.q);
  const [price, setPrice] = useState(current.max);

  useEffect(() => setSearch(current.q), [current.q]);
  useEffect(() => setPrice(current.max), [current.max]);

  const push = useCallback(
    (mutate: (next: URLSearchParams) => void) => {
      const next = new URLSearchParams(params.toString());
      mutate(next);
      startTransition(() => {
        const query = next.toString();
        router.push(query ? `/shop?${query}` : "/shop", { scroll: false });
      });
    },
    [params, router],
  );

  useEffect(() => {
    const timer = setTimeout(() => {
      if (search === current.q) return;
      push((next) => {
        if (search) next.set("q", search);
        else next.delete("q");
      });
    }, 350);
    return () => clearTimeout(timer);
  }, [search, current.q, push]);

  const toggleList = (key: "platform" | "genre", value: string) => {
    const list = key === "platform" ? current.platforms : current.genres;
    const nextList = list.includes(value) ? list.filter((v) => v !== value) : [...list, value];
    push((next) => {
      if (nextList.length) next.set(key, nextList.join(","));
      else next.delete(key);
    });
  };

  const activeCount =
    current.platforms.length +
    current.genres.length +
    (current.collection ? 1 : 0) +
    (current.onSale ? 1 : 0) +
    (current.max < facets.maxPrice ? 1 : 0) +
    (current.q ? 1 : 0);

  const body = (
    <div className={cx("space-y-8", pending && "opacity-60 transition-opacity")}>
      <div>
        <label className="eyebrow block text-gold" htmlFor="shop-search">
          Search
        </label>
        <div className="mt-3 flex items-center rounded-full border border-edge bg-panel/50 focus-within:border-gold/50">
          <span className="pl-3.5 text-mist">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="11" cy="11" r="7" />
              <path d="m20 20-3.5-3.5" />
            </svg>
          </span>
          <input
            id="shop-search"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Title, studio, genre…"
            className="w-full bg-transparent px-3 py-2.5 text-sm outline-none placeholder:text-mist/60"
          />
        </div>
      </div>

      <div>
        <p className="eyebrow text-gold">Platform</p>
        <ul className="mt-3 space-y-1.5">
          {facets.platforms.map((facet) => {
            const checked = current.platforms.includes(facet.value);
            return (
              <li key={facet.value}>
                <button
                  type="button"
                  onClick={() => toggleList("platform", facet.value)}
                  className="group flex w-full items-center gap-3 rounded-lg px-2 py-1.5 text-left transition hover:bg-panel/60"
                >
                  <span
                    className={cx(
                      "grid size-4 shrink-0 place-items-center rounded border transition",
                      checked ? "border-gold bg-gold text-void" : "border-edge text-transparent",
                    )}
                  >
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.5">
                      <path d="m4 12 5 5L20 6" />
                    </svg>
                  </span>
                  <span className={cx("flex-1 text-sm", checked ? "text-bone" : "text-mist")}>
                    {facet.value}
                  </span>
                  <span className="text-[11px] text-mist/70 tabular-nums">{facet.count}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </div>

      <div>
        <p className="eyebrow text-gold">Genre</p>
        <ul className="mt-3 flex flex-wrap gap-2">
          {facets.genres.map((facet) => {
            const checked = current.genres.includes(facet.value);
            return (
              <li key={facet.value}>
                <button
                  type="button"
                  onClick={() => toggleList("genre", facet.value)}
                  className={cx(
                    "rounded-full border px-3 py-1.5 text-xs transition",
                    checked
                      ? "border-gold bg-gold/15 text-gold-soft"
                      : "border-edge text-mist hover:border-mist/40 hover:text-bone",
                  )}
                >
                  {facet.value}
                  <span className="ml-1.5 text-[10px] opacity-60 tabular-nums">{facet.count}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </div>

      <div>
        <div className="flex items-center justify-between">
          <p className="eyebrow text-gold">Max price</p>
          <span className="text-sm tabular-nums">{formatPrice(price)}</span>
        </div>
        <input
          type="range"
          min={1000}
          max={facets.maxPrice}
          step={500}
          value={price}
          onChange={(event) => setPrice(Number(event.target.value))}
          onMouseUp={() =>
            push((next) => {
              if (price >= facets.maxPrice) next.delete("max");
              else next.set("max", String(price));
            })
          }
          onTouchEnd={() =>
            push((next) => {
              if (price >= facets.maxPrice) next.delete("max");
              else next.set("max", String(price));
            })
          }
          className="mt-4 h-1 w-full cursor-pointer appearance-none rounded-full bg-edge accent-gold"
        />
      </div>

      <div>
        <p className="eyebrow text-gold">Collection</p>
        <div className="mt-3 space-y-1.5">
          <button
            type="button"
            onClick={() => push((next) => next.delete("collection"))}
            className={cx(
              "block w-full rounded-lg px-2 py-1.5 text-left text-sm transition hover:bg-panel/60",
              current.collection ? "text-mist" : "text-gold-soft",
            )}
          >
            All collections
          </button>
          {collections.map((collection) => (
            <button
              key={collection.slug}
              type="button"
              onClick={() =>
                push((next) =>
                  current.collection === collection.slug
                    ? next.delete("collection")
                    : next.set("collection", collection.slug),
                )
              }
              className={cx(
                "block w-full rounded-lg px-2 py-1.5 text-left text-sm transition hover:bg-panel/60",
                current.collection === collection.slug ? "text-gold-soft" : "text-mist",
              )}
            >
              {collection.name}
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-center justify-between rounded-xl border border-edge bg-panel/40 px-4 py-3">
        <span className="text-sm">On sale only</span>
        <button
          type="button"
          role="switch"
          aria-checked={current.onSale}
          onClick={() =>
            push((next) => (current.onSale ? next.delete("onSale") : next.set("onSale", "1")))
          }
          className={cx(
            "relative h-6 w-11 rounded-full transition",
            current.onSale ? "bg-gold" : "bg-edge",
          )}
        >
          <span
            className={cx(
              "absolute top-0.5 size-5 rounded-full bg-bone transition-transform",
              current.onSale ? "translate-x-[22px]" : "translate-x-[2px]",
            )}
          />
        </button>
      </div>

      {activeCount > 0 && (
        <button
          type="button"
          onClick={() => startTransition(() => router.push("/shop", { scroll: false }))}
          className="w-full rounded-full border border-edge px-4 py-2.5 text-sm text-mist transition hover:border-rose-400/50 hover:text-rose-300"
        >
          Clear {activeCount} filter{activeCount === 1 ? "" : "s"}
        </button>
      )}
    </div>
  );

  return (
    <>
      {/* toolbar */}
      <div className="mb-6 flex items-center justify-between gap-3 lg:hidden">
        <button
          type="button"
          onClick={() => setMobileOpen(true)}
          className="flex items-center gap-2 rounded-full border border-edge px-4 py-2.5 text-sm"
        >
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M4 6h16M7 12h10M10 18h4" />
          </svg>
          Filters
          {activeCount > 0 && (
            <span className="grid size-5 place-items-center rounded-full bg-gold text-[10px] font-bold text-void">
              {activeCount}
            </span>
          )}
        </button>
        <SortSelect />
      </div>

      <div className="hidden lg:block">
        <div className="sticky top-28">
          <div className="mb-6 flex items-center justify-between">
            <p className="font-display text-2xl">Filters</p>
            <span className="text-xs text-mist tabular-nums">{resultCount} results</span>
          </div>
          {body}
        </div>
      </div>

      {/* mobile drawer */}
      <div
        className={cx(
          "fixed inset-0 z-[85] lg:hidden",
          mobileOpen ? "pointer-events-auto" : "pointer-events-none",
        )}
      >
        <button
          type="button"
          aria-label="Close filters"
          onClick={() => setMobileOpen(false)}
          className={cx(
            "absolute inset-0 bg-black/70 backdrop-blur-sm transition-opacity",
            mobileOpen ? "opacity-100" : "opacity-0",
          )}
        />
        <div
          className={cx(
            "absolute inset-y-0 left-0 w-[88%] max-w-sm overflow-y-auto border-r border-edge bg-ink p-6 transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]",
            mobileOpen ? "translate-x-0" : "-translate-x-full",
          )}
        >
          <div className="mb-6 flex items-center justify-between">
            <p className="font-display text-2xl">Filters</p>
            <button
              type="button"
              onClick={() => setMobileOpen(false)}
              className="grid size-9 place-items-center rounded-full border border-edge text-mist"
              aria-label="Close filters"
            >
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M18 6 6 18M6 6l12 12" />
              </svg>
            </button>
          </div>
          {body}
          <button
            type="button"
            onClick={() => setMobileOpen(false)}
            className="mt-8 w-full rounded-full bg-bone px-5 py-3 text-sm font-bold text-void"
          >
            Show {resultCount} results
          </button>
        </div>
      </div>
    </>
  );
}

export function SortSelect() {
  const router = useRouter();
  const params = useSearchParams();
  const value = params.get("sort") ?? "featured";

  return (
    <div className="relative">
      <select
        value={value}
        onChange={(event) => {
          const next = new URLSearchParams(params.toString());
          if (event.target.value === "featured") next.delete("sort");
          else next.set("sort", event.target.value);
          const query = next.toString();
          router.push(query ? `/shop?${query}` : "/shop", { scroll: false });
        }}
        className="appearance-none rounded-full border border-edge bg-panel/50 py-2.5 pl-4 pr-10 text-sm text-bone outline-none transition hover:border-gold/40"
        aria-label="Sort products"
      >
        {SORT_OPTIONS.map((option) => (
          <option key={option.value} value={option.value} className="bg-ink">
            {option.label}
          </option>
        ))}
      </select>
      <span className="pointer-events-none absolute right-3.5 top-1/2 -translate-y-1/2 text-mist">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="m6 9 6 6 6-6" />
        </svg>
      </span>
    </div>
  );
}
