import Link from "next/link";
import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import { isAdmin } from "@/lib/admin";
import { AdminSignOut } from "./admin-signout";

export const dynamic = "force-dynamic";

const NAV = [
  { href: "/admin", label: "Dashboard" },
  { href: "/admin/products", label: "Catalogue" },
  { href: "/admin/orders", label: "Orders & reviews" },
  { href: "/shop", label: "View storefront" },
];

export default async function AdminLayout({ children }: { children: ReactNode }) {
  if (!(await isAdmin())) redirect("/admin/login");

  return (
    <div className="mx-auto max-w-[1400px] px-5 py-10 sm:px-8">
      <div className="flex flex-col gap-6 border-b border-edge pb-6 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <p className="eyebrow text-gold">Bha Khan back office</p>
          <h1 className="mt-2 font-display text-4xl leading-none">Operations console</h1>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="rounded-full border border-edge px-4 py-2 text-xs text-mist transition hover:border-gold/50 hover:text-bone"
            >
              {item.label}
            </Link>
          ))}
          <AdminSignOut />
        </div>
      </div>
      <div className="mt-8">{children}</div>
    </div>
  );
}
