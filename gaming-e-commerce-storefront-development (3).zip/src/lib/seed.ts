import { db } from "@/db";
import { collections, products, reviews } from "@/db/schema";
import { collectionSeed, productSeed, reviewSeed } from "./seed-data";
import { sql } from "drizzle-orm";

let seedPromise: Promise<void> | null = null;

async function runSeed(force = false) {
  if (!force) {
    const existing = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(products);
    if ((existing[0]?.count ?? 0) > 0) return;
  } else {
    await db.delete(reviews);
    await db.delete(products);
    await db.delete(collections);
  }

  await db.insert(collections).values(collectionSeed).onConflictDoNothing();

  const stats = new Map<string, { sum: number; count: number }>();
  for (const review of reviewSeed) {
    const entry = stats.get(review.productSlug) ?? { sum: 0, count: 0 };
    entry.sum += review.rating;
    entry.count += 1;
    stats.set(review.productSlug, entry);
  }

  await db
    .insert(products)
    .values(
      productSeed.map((product) => {
        const stat = stats.get(product.slug);
        return {
          slug: product.slug,
          title: product.title,
          tagline: product.tagline,
          description: product.description,
          story: product.story,
          price: product.price,
          compareAtPrice: product.compareAtPrice ?? null,
          platform: product.platform,
          genre: product.genre,
          edition: product.edition,
          publisher: product.publisher,
          developer: product.developer,
          releaseYear: product.releaseYear,
          rated: product.rated,
          players: product.players,
          playtime: product.playtime,
          stock: product.stock,
          featured: product.featured,
          isNew: product.isNew,
          collectionSlug: product.collectionSlug,
          coverImage: product.coverImage,
          gallery: product.gallery,
          highlights: product.highlights,
          tags: product.tags,
          ratingAvg: stat ? Math.round((stat.sum / stat.count) * 10) / 10 : 0,
          ratingCount: stat?.count ?? 0,
          soldCount: product.soldCount,
          sortOrder: product.sortOrder,
        };
      }),
    )
    .onConflictDoNothing();

  const now = Date.now();
  await db.insert(reviews).values(
    reviewSeed.map((review) => ({
      productSlug: review.productSlug,
      author: review.author,
      location: review.location,
      rating: review.rating,
      title: review.title,
      body: review.body,
      verified: true,
      helpful: review.helpful,
      createdAt: new Date(now - review.daysAgo * 86_400_000),
    })),
  );
}

export function ensureSeeded() {
  if (!seedPromise) {
    seedPromise = runSeed().catch((error) => {
      seedPromise = null;
      throw error;
    });
  }
  return seedPromise;
}

export async function reseed() {
  seedPromise = runSeed(true);
  await seedPromise;
}
