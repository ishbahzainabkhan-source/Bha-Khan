"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { useCart } from "@/components/cart/cart-provider";
import { cx, formatPrice } from "@/lib/format";
import { PROMOS, priceOrder } from "@/lib/promos";

const STEPS = ["Contact", "Delivery", "Payment", "Review"] as const;

const COUNTRIES = [
  "United States",
  "United Kingdom",
  "Canada",
  "Australia",
  "Germany",
  "France",
  "Japan",
  "Singapore",
  "United Arab Emirates",
];

type Form = {
  email: string;
  fullName: string;
  address: string;
  city: string;
  postalCode: string;
  country: string;
  deliveryMethod: "digital" | "express";
  card: string;
  expiry: string;
  cvc: string;
  marketing: boolean;
};

const EMPTY: Form = {
  email: "",
  fullName: "",
  address: "",
  city: "",
  postalCode: "",
  country: "United States",
  deliveryMethod: "express",
  card: "",
  expiry: "",
  cvc: "",
  marketing: true,
};

function Field({
  label,
  children,
  hint,
}: {
  label: string;
  children: React.ReactNode;
  hint?: string;
}) {
  return (
    <label className="block">
      <span className="eyebrow block text-mist">{label}</span>
      <div className="mt-2">{children}</div>
      {hint ? <span className="mt-1.5 block text-[11px] text-mist/70">{hint}</span> : null}
    </label>
  );
}

const inputClass =
  "w-full rounded-xl border border-edge bg-void/60 px-4 py-3 text-sm outline-none transition focus:border-gold/50 placeholder:text-mist/50";

export function CheckoutClient() {
  const { items, subtotal, savings, clearCart, hydrated } = useCart();
  const router = useRouter();

  const [step, setStep] = useState(0);
  const [form, setForm] = useState<Form>(EMPTY);
  const [promoInput, setPromoInput] = useState("");
  const [promoCode, setPromoCode] = useState("");
  const [promoError, setPromoError] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const update = <K extends keyof Form>(key: K, value: Form[K]) =>
    setForm((current) => ({ ...current, [key]: value }));

  const totals = useMemo(
    () => priceOrder({ subtotal, promoCode, deliveryMethod: form.deliveryMethod }),
    [subtotal, promoCode, form.deliveryMethod],
  );

  const stepValid = useMemo(() => {
    if (step === 0) return form.email.includes("@") && form.fullName.trim().length > 1;
    if (step === 1) {
      if (form.deliveryMethod === "digital") return true;
      return (
        form.address.trim().length > 3 &&
        form.city.trim().length > 1 &&
        form.postalCode.trim().length > 2
      );
    }
    if (step === 2) {
      return (
        form.card.replace(/\s/g, "").length >= 15 &&
        /^\d{2}\s?\/\s?\d{2}$/.test(form.expiry) &&
        form.cvc.length >= 3
      );
    }
    return true;
  }, [step, form]);

  const applyPromo = () => {
    const code = promoInput.trim().toUpperCase();
    if (!code) return;
    if (PROMOS[code]) {
      setPromoCode(code);
      setPromoError("");
    } else {
      setPromoCode("");
      setPromoError("That code isn't recognised.");
    }
  };

  const placeOrder = async () => {
    setSubmitting(true);
    setError("");
    try {
      const response = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: items.map((item) => ({ slug: item.slug, quantity: item.quantity })),
          email: form.email,
          fullName: form.fullName,
          address: form.address,
          city: form.city,
          postalCode: form.postalCode,
          country: form.country,
          deliveryMethod: form.deliveryMethod,
          promoCode,
        }),
      });
      const data = (await response.json()) as { orderNumber?: string; error?: string };
      if (!response.ok || !data.orderNumber) {
        throw new Error(data.error ?? "Something went wrong.");
      }
      clearCart();
      router.push(`/orders/${data.orderNumber}`);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Something went wrong.");
      setSubmitting(false);
    }
  };

  if (hydrated && items.length === 0) {
    return (
      <div className="mx-auto max-w-xl rounded-3xl border border-dashed border-edge px-8 py-24 text-center">
        <p className="font-display text-4xl">Your bag is empty</p>
        <p className="mx-auto mt-3 max-w-sm text-sm text-mist">
          Add a title or two and we&apos;ll get you checked out in under a minute.
        </p>
        <Link
          href="/shop"
          className="mt-8 inline-block rounded-full bg-bone px-8 py-3.5 text-sm font-bold text-void transition hover:bg-gold-soft"
        >
          Browse the shop
        </Link>
      </div>
    );
  }

  return (
    <div className="grid gap-12 lg:grid-cols-[1.25fr_0.85fr] lg:gap-16">
      <div>
        {/* step rail */}
        <ol className="flex flex-wrap items-center gap-x-3 gap-y-2">
          {STEPS.map((label, index) => (
            <li key={label} className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => index < step && setStep(index)}
                className={cx(
                  "flex items-center gap-2 rounded-full border px-3.5 py-1.5 text-xs transition",
                  index === step
                    ? "border-gold/60 bg-gold/10 text-gold-soft"
                    : index < step
                      ? "border-edge text-bone hover:border-gold/40"
                      : "border-edge text-mist",
                )}
              >
                <span
                  className={cx(
                    "grid size-5 place-items-center rounded-full text-[10px] font-bold",
                    index <= step ? "bg-gold text-void" : "bg-edge text-mist",
                  )}
                >
                  {index < step ? "✓" : index + 1}
                </span>
                {label}
              </button>
              {index < STEPS.length - 1 && <span className="h-px w-5 bg-edge" />}
            </li>
          ))}
        </ol>

        <div className="mt-8 rounded-3xl border border-edge bg-panel/30 p-6 sm:p-8">
          {step === 0 && (
            <div className="space-y-5">
              <div>
                <h2 className="font-display text-3xl">Who are we shipping to?</h2>
                <p className="mt-2 text-sm text-mist">
                  We&apos;ll email your receipt, tracking and any digital keys here.
                </p>
              </div>
              <Field label="Full name">
                <input
                  className={inputClass}
                  value={form.fullName}
                  onChange={(event) => update("fullName", event.target.value)}
                  placeholder="Alex Morgan"
                  autoComplete="name"
                />
              </Field>
              <Field label="Email address" hint="Digital keys arrive within 60 seconds.">
                <input
                  className={inputClass}
                  type="email"
                  value={form.email}
                  onChange={(event) => update("email", event.target.value)}
                  placeholder="you@example.com"
                  autoComplete="email"
                />
              </Field>
              <label className="flex items-start gap-3 text-sm text-mist">
                <input
                  type="checkbox"
                  checked={form.marketing}
                  onChange={(event) => update("marketing", event.target.checked)}
                  className="mt-0.5 size-4 accent-[#d9b26a]"
                />
                Email me The Dispatch — one weekly email with price drops and staff reviews.
              </label>
            </div>
          )}

          {step === 1 && (
            <div className="space-y-5">
              <div>
                <h2 className="font-display text-3xl">Delivery</h2>
                <p className="mt-2 text-sm text-mist">Pick how you&apos;d like your games.</p>
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                {(
                  [
                    {
                      key: "express",
                      title: "Express courier",
                      body: "2–4 working days, tracked & insured",
                      price: subtotal >= 7500 ? "Free" : formatPrice(599),
                    },
                    {
                      key: "digital",
                      title: "Digital keys",
                      body: "Delivered by email in under a minute",
                      price: "Free",
                    },
                  ] as const
                ).map((option) => (
                  <button
                    key={option.key}
                    type="button"
                    onClick={() => update("deliveryMethod", option.key)}
                    className={cx(
                      "rounded-2xl border p-5 text-left transition",
                      form.deliveryMethod === option.key
                        ? "border-gold/60 bg-gold/10"
                        : "border-edge hover:border-mist/40",
                    )}
                  >
                    <span className="flex items-center justify-between">
                      <span className="font-semibold">{option.title}</span>
                      <span className="text-sm tabular-nums">{option.price}</span>
                    </span>
                    <span className="mt-1 block text-xs text-mist">{option.body}</span>
                  </button>
                ))}
              </div>

              {form.deliveryMethod === "express" && (
                <div className="grid gap-5">
                  <Field label="Street address">
                    <input
                      className={inputClass}
                      value={form.address}
                      onChange={(event) => update("address", event.target.value)}
                      placeholder="14 Lantern Row"
                      autoComplete="street-address"
                    />
                  </Field>
                  <div className="grid gap-5 sm:grid-cols-2">
                    <Field label="City">
                      <input
                        className={inputClass}
                        value={form.city}
                        onChange={(event) => update("city", event.target.value)}
                        placeholder="Manchester"
                        autoComplete="address-level2"
                      />
                    </Field>
                    <Field label="Postal code">
                      <input
                        className={inputClass}
                        value={form.postalCode}
                        onChange={(event) => update("postalCode", event.target.value)}
                        placeholder="M1 4AB"
                        autoComplete="postal-code"
                      />
                    </Field>
                  </div>
                  <Field label="Country">
                    <select
                      className={inputClass}
                      value={form.country}
                      onChange={(event) => update("country", event.target.value)}
                    >
                      {COUNTRIES.map((country) => (
                        <option key={country} value={country} className="bg-ink">
                          {country}
                        </option>
                      ))}
                    </select>
                  </Field>
                </div>
              )}
            </div>
          )}

          {step === 2 && (
            <div className="space-y-5">
              <div>
                <h2 className="font-display text-3xl">Payment</h2>
                <p className="mt-2 text-sm text-mist">
                  Demo storefront — use any digits, no card is ever charged.
                </p>
              </div>
              <Field label="Card number">
                <input
                  className={cx(inputClass, "tracking-[0.18em] tabular-nums")}
                  value={form.card}
                  inputMode="numeric"
                  onChange={(event) =>
                    update(
                      "card",
                      event.target.value
                        .replace(/\D/g, "")
                        .slice(0, 16)
                        .replace(/(.{4})/g, "$1 ")
                        .trim(),
                    )
                  }
                  placeholder="4242 4242 4242 4242"
                />
              </Field>
              <div className="grid gap-5 sm:grid-cols-2">
                <Field label="Expiry">
                  <input
                    className={cx(inputClass, "tabular-nums")}
                    value={form.expiry}
                    inputMode="numeric"
                    onChange={(event) => {
                      const digits = event.target.value.replace(/\D/g, "").slice(0, 4);
                      update(
                        "expiry",
                        digits.length > 2 ? `${digits.slice(0, 2)}/${digits.slice(2)}` : digits,
                      );
                    }}
                    placeholder="09/28"
                  />
                </Field>
                <Field label="CVC">
                  <input
                    className={cx(inputClass, "tabular-nums")}
                    value={form.cvc}
                    inputMode="numeric"
                    onChange={(event) =>
                      update("cvc", event.target.value.replace(/\D/g, "").slice(0, 4))
                    }
                    placeholder="123"
                  />
                </Field>
              </div>
              <div className="flex items-center gap-2 rounded-xl border border-edge bg-void/40 px-4 py-3 text-xs text-mist">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="text-gold">
                  <rect x="4" y="10" width="16" height="10" rx="2" />
                  <path d="M8 10V7a4 4 0 0 1 8 0v3" />
                </svg>
                Secured with 256-bit TLS. We never store card details.
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <div>
                <h2 className="font-display text-3xl">Review & place order</h2>
                <p className="mt-2 text-sm text-mist">One last look before we pack it up.</p>
              </div>

              <dl className="grid gap-4 sm:grid-cols-2">
                <div className="rounded-xl border border-edge p-4">
                  <dt className="eyebrow text-mist">Contact</dt>
                  <dd className="mt-2 text-sm">
                    {form.fullName}
                    <br />
                    <span className="text-mist">{form.email}</span>
                  </dd>
                </div>
                <div className="rounded-xl border border-edge p-4">
                  <dt className="eyebrow text-mist">Delivery</dt>
                  <dd className="mt-2 text-sm">
                    {form.deliveryMethod === "digital" ? (
                      <>Digital keys by email</>
                    ) : (
                      <>
                        {form.address}
                        <br />
                        <span className="text-mist">
                          {form.city} {form.postalCode}, {form.country}
                        </span>
                      </>
                    )}
                  </dd>
                </div>
              </dl>

              <ul className="divide-y divide-edge rounded-xl border border-edge">
                {items.map((item) => (
                  <li key={item.slug} className="flex items-center gap-4 p-4">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={item.coverImage}
                      alt={item.title}
                      className="size-14 rounded-lg object-cover"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{item.title}</p>
                      <p className="text-[11px] text-mist">
                        {item.edition} · {item.platform} · ×{item.quantity}
                      </p>
                    </div>
                    <span className="text-sm tabular-nums">
                      {formatPrice(item.price * item.quantity)}
                    </span>
                  </li>
                ))}
              </ul>

              {error && (
                <p className="rounded-xl border border-rose-500/40 bg-rose-500/10 px-4 py-3 text-sm text-rose-300">
                  {error}
                </p>
              )}
            </div>
          )}

          <div className="mt-8 flex items-center justify-between gap-4 border-t border-edge pt-6">
            <button
              type="button"
              onClick={() => (step === 0 ? router.push("/shop") : setStep(step - 1))}
              className="text-sm text-mist transition hover:text-bone"
            >
              {step === 0 ? "← Keep shopping" : "← Back"}
            </button>

            {step < STEPS.length - 1 ? (
              <button
                type="button"
                disabled={!stepValid}
                onClick={() => setStep(step + 1)}
                className="rounded-full bg-bone px-8 py-3.5 text-sm font-bold text-void transition hover:bg-gold-soft disabled:cursor-not-allowed disabled:bg-edge disabled:text-mist"
              >
                Continue
              </button>
            ) : (
              <button
                type="button"
                disabled={submitting}
                onClick={placeOrder}
                className="rounded-full bg-gradient-to-r from-gold-soft via-gold to-gold-soft bg-[length:200%_100%] px-8 py-3.5 text-sm font-bold text-void transition-[background-position] duration-700 hover:bg-right disabled:opacity-60"
              >
                {submitting ? "Placing order…" : `Pay ${formatPrice(totals.total)}`}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* ------------------------------------------------------------ SUMMARY */}
      <aside className="lg:sticky lg:top-28 lg:self-start">
        <div className="rounded-3xl border border-edge bg-panel/40 p-6">
          <p className="font-display text-2xl">Order summary</p>

          <ul className="mt-5 space-y-4">
            {items.map((item) => (
              <li key={item.slug} className="flex gap-3">
                <span className="relative">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={item.coverImage}
                    alt={item.title}
                    className="size-16 rounded-lg border border-edge object-cover"
                  />
                  <span className="absolute -right-2 -top-2 grid size-5 place-items-center rounded-full bg-gold text-[10px] font-bold text-void">
                    {item.quantity}
                  </span>
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-medium">{item.title}</span>
                  <span className="block text-[11px] text-mist">{item.edition}</span>
                </span>
                <span className="text-sm tabular-nums">
                  {formatPrice(item.price * item.quantity)}
                </span>
              </li>
            ))}
          </ul>

          <div className="mt-6 border-t border-edge pt-5">
            <div className="flex gap-2">
              <input
                value={promoInput}
                onChange={(event) => setPromoInput(event.target.value.toUpperCase())}
                placeholder="Promo code"
                className="w-full rounded-full border border-edge bg-void/60 px-4 py-2.5 text-xs tracking-widest uppercase outline-none transition focus:border-gold/50 placeholder:tracking-normal placeholder:text-mist/60"
              />
              <button
                type="button"
                onClick={applyPromo}
                className="shrink-0 rounded-full border border-edge px-4 py-2.5 text-xs font-semibold transition hover:border-gold/50 hover:text-gold-soft"
              >
                Apply
              </button>
            </div>
            {promoError && <p className="mt-2 text-[11px] text-rose-400">{promoError}</p>}
            {totals.promo && (
              <p className="mt-2 text-[11px] text-emerald-400">
                {promoCode} applied — {totals.promo.label}
              </p>
            )}
            <p className="mt-2 text-[11px] text-mist">
              Try <span className="text-gold-soft">BHAKHAN10</span> or{" "}
              <span className="text-gold-soft">PLAYER1</span>
            </p>
          </div>

          <dl className="mt-6 space-y-2 border-t border-edge pt-5 text-sm">
            <div className="flex justify-between">
              <dt className="text-mist">Subtotal</dt>
              <dd className="tabular-nums">{formatPrice(subtotal)}</dd>
            </div>
            {savings > 0 && (
              <div className="flex justify-between text-emerald-400">
                <dt>Sale savings (already applied)</dt>
                <dd className="tabular-nums">−{formatPrice(savings)}</dd>
              </div>
            )}
            {totals.discount > 0 && (
              <div className="flex justify-between text-emerald-400">
                <dt>Promo</dt>
                <dd className="tabular-nums">−{formatPrice(totals.discount)}</dd>
              </div>
            )}
            <div className="flex justify-between">
              <dt className="text-mist">Delivery</dt>
              <dd className="tabular-nums">
                {totals.shipping === 0 ? "Free" : formatPrice(totals.shipping)}
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-mist">Estimated tax</dt>
              <dd className="tabular-nums">{formatPrice(totals.tax)}</dd>
            </div>
            <div className="mt-3 flex items-end justify-between border-t border-edge pt-4">
              <dt className="font-display text-xl">Total</dt>
              <dd className="font-display text-3xl tabular-nums">{formatPrice(totals.total)}</dd>
            </div>
          </dl>
        </div>

        <p className="mt-4 px-2 text-[11px] leading-relaxed text-mist">
          This is a demonstration storefront. No payment is processed and no goods are shipped —
          but the order record is really written to the database.
        </p>
      </aside>
    </div>
  );
}
