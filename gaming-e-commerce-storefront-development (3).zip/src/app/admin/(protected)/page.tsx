import Link from "next/link";
import { getAdminStats } from "@/lib/admin";
import { formatDate, formatPrice } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function AdminDashboardPage() {
  const stats = await getAdminStats();
  const aov = stats.orders.count ? Math.round(stats.orders.revenue / stats.orders.count) : 0;
  const maxGenre = Math.max(1, ...stats.genreSplit.map((g) => g.count));

  const kpis = [
    { label: "Revenue booked", value: formatPrice(stats.orders.revenue), sub: `${stats.orders.count} orders` },
    { label: "Units ordered", value: `${stats.orders.units}`, sub: `${stats.products.sold} lifetime sold` },
    { label: "Average order", value: formatPrice(aov), sub: `${formatPrice(stats.orders.discount)} discounted` },
    { label: "Catalogue", value: `${stats.products.count}`, sub: `${stats.products.featured} featured` },
    { label: "Stock on hand", value: `${stats.products.stock}`, sub: `${stats.lowStock.length} titles running low` },
    { label: "Reviews", value: `${stats.reviews.count}`, sub: `${stats.reviews.avg}★ average` },
  ];

  return (
    <div className="space-y-10">
      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        {kpis.map((kpi) => (
          <div key={kpi.label} className="rounded-2xl border border-edge bg-panel/40 p-5">
            <p className="text-[10px] tracking-[0.18em] text-mist uppercase">{kpi.label}</p>
            <p className="mt-2 font-display text-3xl leading-none">{kpi.value}</p>
            <p className="mt-1.5 text-[11px] text-mist">{kpi.sub}</p>
          </div>
        ))}
      </section>

      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <section className="rounded-2xl border border-edge bg-panel/30">
          <header className="flex items-center justify-between border-b border-edge px-6 py-4">
            <h2 className="font-display text-2xl">Latest orders</h2>
            <Link href="/admin/orders" className="text-xs text-mist hover:text-bone">
              Manage all →
            </Link>
          </header>
          {stats.recentOrders.length === 0 ? (
            <p className="px-6 py-12 text-center text-sm text-mist">
              No orders yet. Place one from the storefront and it will appear here instantly.
            </p>
          ) : (
            <ul className="divide-y divide-edge">
              {stats.recentOrders.map((order) => (
                <li key={order.id} className="flex items-center gap-4 px-6 py-4">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">
                      {order.fullName}{" "}
                      <span className="text-mist">· {order.orderNumber}</span>
                    </p>
                    <p className="truncate text-[11px] text-mist">
                      {order.items.length} item{order.items.length === 1 ? "" : "s"} ·{" "}
                      {formatDate(order.createdAt)} · {order.email}
                    </p>
                  </div>
                  <span className="rounded-full border border-edge px-2.5 py-1 text-[10px] tracking-wide text-mist uppercase">
                    {order.status}
                  </span>
                  <span className="text-sm tabular-nums">{formatPrice(order.total)}</span>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="rounded-2xl border border-edge bg-panel/30 p-6">
          <h2 className="font-display text-2xl">Catalogue by genre</h2>
          <ul className="mt-5 space-y-3">
            {stats.genreSplit.map((entry) => (
              <li key={entry.genre} className="flex items-center gap-3 text-xs">
                <span className="w-24 shrink-0 truncate text-mist">{entry.genre}</span>
                <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-edge">
                  <span
                    className="block h-full rounded-full bg-gradient-to-r from-gold/60 to-gold"
                    style={{ width: `${(entry.count / maxGenre) * 100}%` }}
                  />
                </span>
                <span className="w-6 text-right tabular-nums">{entry.count}</span>
              </li>
            ))}
          </ul>
        </section>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="rounded-2xl border border-edge bg-panel/30">
          <header className="flex items-center justify-between border-b border-edge px-6 py-4">
            <h2 className="font-display text-2xl">Low stock</h2>
            <Link href="/admin/products" className="text-xs text-mist hover:text-bone">
              Restock →
            </Link>
          </header>
          <ul className="divide-y divide-edge">
            {stats.lowStock.map((item) => (
              <li key={item.id} className="flex items-center gap-4 px-6 py-3">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={item.coverImage} alt="" className="size-10 rounded-lg object-cover" />
                <span className="min-w-0 flex-1 truncate text-sm">{item.title}</span>
                <span className="text-[11px] text-mist">{item.platform}</span>
                <span
                  className={`rounded-full px-2.5 py-1 text-[10px] font-bold ${
                    item.stock <= 10 ? "bg-rose-500/15 text-rose-300" : "bg-amber-500/15 text-amber-300"
                  }`}
                >
                  {item.stock} left
                </span>
              </li>
            ))}
          </ul>
        </section>

        <section className="rounded-2xl border border-edge bg-panel/30">
          <header className="flex items-center justify-between border-b border-edge px-6 py-4">
            <h2 className="font-display text-2xl">Top rated</h2>
            <Link href="/shop?sort=rating" className="text-xs text-mist hover:text-bone">
              Storefront →
            </Link>
          </header>
          <ul className="divide-y divide-edge">
            {stats.topRated.map((item) => (
              <li key={item.id} className="flex items-center gap-4 px-6 py-3">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={item.coverImage} alt="" className="size-10 rounded-lg object-cover" />
                <span className="min-w-0 flex-1 truncate text-sm">{item.title}</span>
                <span className="text-[11px] text-mist tabular-nums">
                  {item.ratingAvg.toFixed(1)}★ ({item.ratingCount})
                </span>
                <span className="text-xs tabular-nums">{formatPrice(item.price)}</span>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  );
}
