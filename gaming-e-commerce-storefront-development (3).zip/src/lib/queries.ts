import { db } from "@/db";
import { collections, products, reviews, type Product } from "@/db/schema";
import { and, asc, desc, eq, gte, ilike, inArray, isNotNull, lte, ne, or, sql } from "drizzle-orm";
import { ensureSeeded } from "./seed";
import type { SortKey } from "./catalog";

export type { SortKey } from "./catalog";
export { SORT_OPTIONS } from "./catalog";

export type ProductFilters = {
  q?: string;
  platforms?: string[];
  genres?: string[];
  collection?: string;
  maxPrice?: number;
  onSale?: boolean;
  sort?: SortKey;
};

function orderFor(sort: SortKey | undefined) {
  switch (sort) {
    case "price-asc":
      return [asc(products.price), asc(products.sortOrder)];
    case "price-desc":
      return [desc(products.price), asc(products.sortOrder)];
    case "rating":
      return [desc(products.ratingAvg), desc(products.ratingCount)];
    case "newest":
      return [desc(products.releaseYear), desc(products.isNew), asc(products.sortOrder)];
    case "bestselling":
      return [desc(products.soldCount)];
    default:
      return [desc(products.featured), asc(products.sortOrder)];
  }
}

export async function getProducts(filters: ProductFilters = {}): Promise<Product[]> {
  await ensureSeeded();
  const clauses = [];

  if (filters.q) {
    const term = `%${filters.q}%`;
    clauses.push(
      or(
        ilike(products.title, term),
        ilike(products.tagline, term),
        ilike(products.genre, term),
        ilike(products.developer, term),
        ilike(products.publisher, term),
      ),
    );
  }
  if (filters.platforms?.length) clauses.push(inArray(products.platform, filters.platforms));
  if (filters.genres?.length) clauses.push(inArray(products.genre, filters.genres));
  if (filters.collection) clauses.push(eq(products.collectionSlug, filters.collection));
  if (typeof filters.maxPrice === "number") clauses.push(lte(products.price, filters.maxPrice));
  if (filters.onSale) {
    clauses.push(and(isNotNull(products.compareAtPrice), gte(products.compareAtPrice, products.price)));
  }

  const where = clauses.length ? and(...clauses) : undefined;

  return db
    .select()
    .from(products)
    .where(where)
    .orderBy(...orderFor(filters.sort));
}

export async function getFacets() {
  await ensureSeeded();
  const rows = await db
    .select({
      platform: products.platform,
      genre: products.genre,
      price: products.price,
    })
    .from(products);

  const platformCounts = new Map<string, number>();
  const genreCounts = new Map<string, number>();
  let maxPrice = 0;

  for (const row of rows) {
    platformCounts.set(row.platform, (platformCounts.get(row.platform) ?? 0) + 1);
    genreCounts.set(row.genre, (genreCounts.get(row.genre) ?? 0) + 1);
    maxPrice = Math.max(maxPrice, row.price);
  }

  return {
    platforms: [...platformCounts.entries()]
      .map(([value, count]) => ({ value, count }))
      .sort((a, b) => a.value.localeCompare(b.value)),
    genres: [...genreCounts.entries()]
      .map(([value, count]) => ({ value, count }))
      .sort((a, b) => a.value.localeCompare(b.value)),
    maxPrice: Math.ceil(maxPrice / 1000) * 1000,
    total: rows.length,
  };
}

export async function getCollections() {
  await ensureSeeded();
  return db.select().from(collections).orderBy(asc(collections.sortOrder));
}

export async function getCollection(slug: string) {
  await ensureSeeded();
  const rows = await db.select().from(collections).where(eq(collections.slug, slug)).limit(1);
  return rows[0] ?? null;
}

export async function getProduct(slug: string) {
  await ensureSeeded();
  const rows = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
  return rows[0] ?? null;
}

export async function getProductsBySlugs(slugs: string[]) {
  if (!slugs.length) return [];
  await ensureSeeded();
  return db.select().from(products).where(inArray(products.slug, slugs));
}

export async function getReviews(slug: string) {
  await ensureSeeded();
  return db
    .select()
    .from(reviews)
    .where(eq(reviews.productSlug, slug))
    .orderBy(desc(reviews.helpful), desc(reviews.createdAt));
}

export async function getRelatedProducts(product: Product, limit = 4) {
  await ensureSeeded();
  const rows = await db
    .select()
    .from(products)
    .where(
      and(
        ne(products.slug, product.slug),
        or(
          eq(products.collectionSlug, product.collectionSlug),
          eq(products.genre, product.genre),
        ),
      ),
    )
    .orderBy(desc(products.ratingAvg))
    .limit(limit);

  if (rows.length >= limit) return rows;

  const filler = await db
    .select()
    .from(products)
    .where(ne(products.slug, product.slug))
    .orderBy(desc(products.soldCount))
    .limit(limit + 4);

  const seen = new Set(rows.map((r) => r.slug));
  for (const row of filler) {
    if (rows.length >= limit) break;
    if (seen.has(row.slug)) continue;
    rows.push(row);
    seen.add(row.slug);
  }
  return rows;
}

export async function refreshProductRating(slug: string) {
  const agg = await db
    .select({
      avg: sql<number>`coalesce(avg(${reviews.rating}), 0)`,
      count: sql<number>`count(*)::int`,
    })
    .from(reviews)
    .where(eq(reviews.productSlug, slug));

  const avg = Number(agg[0]?.avg ?? 0);
  const count = Number(agg[0]?.count ?? 0);

  await db
    .update(products)
    .set({ ratingAvg: Math.round(avg * 10) / 10, ratingCount: count })
    .where(eq(products.slug, slug));
}

export async function getTopReviews(limit = 6) {
  await ensureSeeded();
  return db
    .select({
      id: reviews.id,
      author: reviews.author,
      location: reviews.location,
      rating: reviews.rating,
      title: reviews.title,
      body: reviews.body,
      helpful: reviews.helpful,
      productSlug: reviews.productSlug,
      productTitle: products.title,
      productCover: products.coverImage,
    })
    .from(reviews)
    .innerJoin(products, eq(products.slug, reviews.productSlug))
    .where(eq(reviews.rating, 5))
    .orderBy(desc(reviews.helpful))
    .limit(limit);
}

export async function getStorefrontStats() {
  await ensureSeeded();
  const rows = await db
    .select({
      total: sql<number>`count(*)::int`,
      ratings: sql<number>`coalesce(sum(${products.ratingCount}), 0)::int`,
      sold: sql<number>`coalesce(sum(${products.soldCount}), 0)::int`,
    })
    .from(products);
  return rows[0] ?? { total: 0, ratings: 0, sold: 0 };
}
