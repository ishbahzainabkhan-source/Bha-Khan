import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { BuyBox } from "@/components/product/buy-box";
import { Gallery } from "@/components/product/gallery";
import { ReviewsSection, type ReviewItem } from "@/components/product/reviews-section";
import { ProductCard } from "@/components/product/product-card";
import { Reveal } from "@/components/ui/reveal";
import { Stars } from "@/components/ui/stars";
import { getCollection, getProduct, getRelatedProducts, getReviews } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const product = await getProduct(slug);
  if (!product) return { title: "Game not found" };
  return {
    title: product.title,
    description: product.description,
  };
}

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = await getProduct(slug);
  if (!product) notFound();

  const [reviewRows, related, collection] = await Promise.all([
    getReviews(product.slug),
    getRelatedProducts(product, 4),
    getCollection(product.collectionSlug),
  ]);

  const reviews: ReviewItem[] = reviewRows.map((review) => ({
    id: review.id,
    author: review.author,
    location: review.location,
    rating: review.rating,
    title: review.title,
    body: review.body,
    verified: review.verified,
    helpful: review.helpful,
    createdAt: review.createdAt.toISOString(),
  }));

  const specs: [string, string][] = [
    ["Platform", product.platform],
    ["Genre", product.genre],
    ["Edition", product.edition],
    ["Developer", product.developer],
    ["Publisher", product.publisher],
    ["Released", String(product.releaseYear)],
    ["Rating", product.rated],
    ["Players", product.players],
    ["Average playtime", product.playtime],
    ["SKU", `BK-${product.slug.toUpperCase().slice(0, 10)}-${product.id}`],
  ];

  return (
    <div className="mx-auto max-w-[1400px] px-5 pt-10 sm:px-8">
      <nav className="flex flex-wrap items-center gap-2 text-xs text-mist">
        <Link href="/" className="hover:text-bone">
          Home
        </Link>
        <span>/</span>
        <Link href="/shop" className="hover:text-bone">
          Shop
        </Link>
        {collection ? (
          <>
            <span>/</span>
            <Link href={`/collections/${collection.slug}`} className="hover:text-bone">
              {collection.name}
            </Link>
          </>
        ) : null}
        <span>/</span>
        <span className="text-bone">{product.title}</span>
      </nav>

      <div className="mt-8 grid gap-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)] lg:gap-16">
        <Gallery
          images={product.gallery}
          title={product.title}
          badge={product.isNew ? "New release" : undefined}
        />

        <div>
          <Reveal>
            <div className="flex flex-wrap items-center gap-2 text-[11px] tracking-[0.18em] text-mist uppercase">
              <span className="rounded-full border border-edge px-2.5 py-1">{product.platform}</span>
              <span className="rounded-full border border-edge px-2.5 py-1">{product.genre}</span>
              {collection ? (
                <Link
                  href={`/collections/${collection.slug}`}
                  className="rounded-full border border-gold/30 bg-gold/10 px-2.5 py-1 text-gold-soft"
                >
                  {collection.name}
                </Link>
              ) : null}
            </div>

            <h1 className="mt-5 font-display text-[clamp(2.5rem,5.5vw,4.5rem)] leading-[0.95]">
              {product.title}
            </h1>
            <p className="mt-3 font-display text-xl text-gold-soft italic">{product.tagline}</p>

            <a href="#reviews" className="mt-5 inline-flex items-center gap-3 text-sm">
              <Stars value={product.ratingAvg} size={16} />
              <span className="tabular-nums">{product.ratingAvg.toFixed(1)}</span>
              <span className="text-mist underline-offset-4 hover:underline">
                {product.ratingCount} verified reviews
              </span>
            </a>

            <p className="mt-6 text-sm leading-relaxed text-mist sm:text-base">
              {product.description}
            </p>
          </Reveal>

          <div className="mt-8">
            <BuyBox product={product} />
          </div>

          <div className="mt-8 flex flex-wrap gap-2">
            {product.tags.map((tag) => (
              <Link
                key={tag}
                href={`/shop?q=${encodeURIComponent(tag)}`}
                className="rounded-full border border-edge px-3 py-1.5 text-xs text-mist transition hover:border-gold/40 hover:text-bone"
              >
                #{tag}
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* ---------------------------------------------------------- DETAILS */}
      <section className="mt-20 grid gap-12 border-t border-edge pt-14 lg:grid-cols-[1.4fr_1fr] lg:gap-20">
        <Reveal>
          <p className="eyebrow text-gold">The long version</p>
          <h2 className="mt-3 font-display text-4xl">About this game</h2>
          <p className="mt-6 text-sm leading-[1.9] text-mist sm:text-base">{product.story}</p>

          <h3 className="mt-10 font-display text-2xl">Why we stock it</h3>
          <ul className="mt-4 grid gap-3 sm:grid-cols-2">
            {product.highlights.map((highlight) => (
              <li
                key={highlight}
                className="flex gap-3 rounded-xl border border-edge bg-panel/30 p-4 text-sm text-bone/85"
              >
                <span className="mt-1 size-1.5 shrink-0 rounded-full bg-gold" />
                {highlight}
              </li>
            ))}
          </ul>
        </Reveal>

        <Reveal delay={120}>
          <div className="rounded-2xl border border-edge bg-panel/30 p-6">
            <p className="eyebrow text-gold">Specifications</p>
            <dl className="mt-5 divide-y divide-edge">
              {specs.map(([label, value]) => (
                <div key={label} className="flex items-start justify-between gap-6 py-3">
                  <dt className="text-xs tracking-wide text-mist uppercase">{label}</dt>
                  <dd className="text-right text-sm">{value}</dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="mt-6 rounded-2xl border border-edge bg-gradient-to-br from-panel/60 to-void p-6">
            <p className="font-display text-2xl">Shop notes</p>
            <p className="mt-3 text-sm leading-relaxed text-mist">
              Every copy is checked at the counter before it ships. If a disc arrives scuffed or a
              key fails to redeem, message us and we replace it the same day — no receipt gymnastics.
            </p>
            <p className="mt-4 text-xs text-gold-soft">— The Bha Khan counter team</p>
          </div>
        </Reveal>
      </section>

      {/* ---------------------------------------------------------- REVIEWS */}
      <div className="mt-20">
        <ReviewsSection
          productSlug={product.slug}
          productTitle={product.title}
          initialReviews={reviews}
        />
      </div>

      {/* ---------------------------------------------------------- RELATED */}
      {related.length > 0 && (
        <section className="mt-20 border-t border-edge pt-14">
          <Reveal className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="eyebrow text-gold">Keep browsing</p>
              <h2 className="mt-3 font-display text-4xl">You might also like</h2>
            </div>
            <Link href="/shop" className="text-sm text-mist transition hover:text-bone">
              Back to the shelves →
            </Link>
          </Reveal>
          <div className="mt-8 grid grid-cols-2 gap-5 lg:grid-cols-4">
            {related.map((item, index) => (
              <Reveal key={item.slug} delay={(index % 4) * 70}>
                <ProductCard product={item} />
              </Reveal>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
